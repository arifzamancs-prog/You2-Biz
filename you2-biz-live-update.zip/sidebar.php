<?php

require_once __DIR__ . '/product_expiry_helper.php';
require_once __DIR__ . '/app_config.php';
require_once __DIR__ . '/restaurant_table_helper.php';
require_once __DIR__ . '/staff_incentive_helper.php';
require_once __DIR__ . '/project_package_helper.php';
require_once __DIR__ . '/pricing_plan_visibility_helper.php';
require_once __DIR__ . '/sidebar_settings_helper.php';
require_once __DIR__ . '/multi_branch_helper.php';

$sidebar_avatar_file = $_SESSION['avatar'] ?? 'you2biz.png';
$sidebar_name = $_SESSION['user_name'] ?? 'Profile';
if(is_manager_user() && isset($conn) && $conn instanceof mysqli){
    $company_user_id = (int)($_SESSION['user_id'] ?? 0);
    $login_user_id = (int)($_SESSION['login_user_id'] ?? 0);

    if($login_user_id > 0){
        $company_from_login_stmt = mysqli_prepare(
            $conn,
            "SELECT
                company.id,
                company.name,
                company.avatar
             FROM users login_user
             LEFT JOIN users company
                ON company.id = CASE
                    WHEN login_user.owner_id IS NULL OR login_user.owner_id = 0
                    THEN login_user.id
                    ELSE login_user.owner_id
                END
             WHERE login_user.id=?
             LIMIT 1"
        );

        if($company_from_login_stmt){
            mysqli_stmt_bind_param($company_from_login_stmt, "i", $login_user_id);
            mysqli_stmt_execute($company_from_login_stmt);
            $company_from_login_result = mysqli_stmt_get_result($company_from_login_stmt);
            $company_from_login = $company_from_login_result
                ? mysqli_fetch_assoc($company_from_login_result)
                : null;

            if(
                $company_from_login &&
                (int)($company_from_login['id'] ?? 0) > 0 &&
                (int)$company_from_login['id'] !== $login_user_id
            ){
                $company_user_id = (int)$company_from_login['id'];
                $sidebar_name = $company_from_login['name'] ?: $sidebar_name;
                $sidebar_avatar_file = $company_from_login['avatar'] ?: $sidebar_avatar_file;
                $_SESSION['user_id'] = $company_user_id;
                $_SESSION['user_name'] = $sidebar_name;
                $_SESSION['avatar'] = $sidebar_avatar_file;
            }
        }
    }

    if($company_user_id === $login_user_id && $login_user_id > 0){
        $fallback_owner_result = mysqli_query(
            $conn,
            "SELECT id
             FROM users
             WHERE role='admin'
             AND status='active'
             ORDER BY id DESC
             LIMIT 1"
        );

        $fallback_owner = $fallback_owner_result
            ? mysqli_fetch_assoc($fallback_owner_result)
            : null;

        if($fallback_owner && (int)$fallback_owner['id'] > 0){
            $company_user_id = (int)$fallback_owner['id'];
            $_SESSION['user_id'] = $company_user_id;

            $owner_update_stmt = mysqli_prepare(
                $conn,
                "UPDATE users
                 SET owner_id=?
                 WHERE id=?
                 AND role='manager'"
            );

            if($owner_update_stmt){
                mysqli_stmt_bind_param(
                    $owner_update_stmt,
                    "ii",
                    $company_user_id,
                    $login_user_id
                );
                mysqli_stmt_execute($owner_update_stmt);
            }
        }
    }

    if($company_user_id > 0){
        $company_stmt = mysqli_prepare(
            $conn,
            "SELECT name, avatar
             FROM users
             WHERE id=?
             LIMIT 1"
        );

        if($company_stmt){
            mysqli_stmt_bind_param($company_stmt, "i", $company_user_id);
            mysqli_stmt_execute($company_stmt);
            $company_result = mysqli_stmt_get_result($company_stmt);
            $company = $company_result ? mysqli_fetch_assoc($company_result) : null;

            if($company){
                $sidebar_name = $company['name'] ?: $sidebar_name;
                $sidebar_avatar_file = $company['avatar'] ?: $sidebar_avatar_file;
                $_SESSION['user_name'] = $sidebar_name;
                $_SESSION['avatar'] = $sidebar_avatar_file;
            }
        }
    }
}

$project_package_labels = !is_super_admin_user() && isset($conn) && $conn instanceof mysqli
    ? project_package_labels($conn, (int)($_SESSION['user_id'] ?? 0))
    : [
        'module' => 'Project & Package',
        'project' => 'Project',
        'package_list' => 'Package List',
    ];

$sidebar_stock_receive_pending_count = 0;
if (isset($conn) && $conn instanceof mysqli && !is_super_admin_user()) {
    $sidebar_company_id = (int)($_SESSION['user_id'] ?? 0);
    $sidebar_branch_id = selected_branch_id($conn, true);
    if ($sidebar_company_id > 0 && $sidebar_branch_id > 0 && !empty($_SESSION['stock_product_enabled']) && company_multi_branch_enabled($conn, $sidebar_company_id)) {
        $sidebar_receive_stmt = mysqli_prepare($conn, "SELECT COALESCE(SUM(quantity),0) AS total FROM stock_distributions WHERE user_id=? AND to_branch_id=? AND status='pending'");
        if ($sidebar_receive_stmt) {
            mysqli_stmt_bind_param($sidebar_receive_stmt, 'ii', $sidebar_company_id, $sidebar_branch_id);
            mysqli_stmt_execute($sidebar_receive_stmt);
            $sidebar_stock_receive_pending_count = (int)(mysqli_fetch_assoc(mysqli_stmt_get_result($sidebar_receive_stmt))['total'] ?? 0);
            mysqli_stmt_close($sidebar_receive_stmt);
        }
    }
}

$sidebar_avatar = app_path('uploads/avatars/you2biz.png');

if(
    !empty($sidebar_avatar_file) &&
    file_exists(
        dirname(__DIR__) .
        '/uploads/avatars/' .
        $sidebar_avatar_file
    )
){
    $sidebar_avatar = app_path('uploads/avatars/') . $sidebar_avatar_file;
}

$sidebar_role = is_super_admin_user()
    ? 'Super Admin'
    : (is_manager_user()
        ? 'Staff Access'
        : 'Administrator');

// A staff login is linked with a staff record. Show that person's actual
// designation under the company name instead of the generic account type.
if(is_manager_user() && isset($conn) && $conn instanceof mysqli){
    $sidebar_login_user_id = (int)($_SESSION['login_user_id'] ?? 0);

    if($sidebar_login_user_id > 0){
        $sidebar_designation_stmt = mysqli_prepare(
            $conn,
            "SELECT s.designation
             FROM users u
             INNER JOIN staff s
                ON s.id=u.staff_id
                AND s.user_id=u.owner_id
             WHERE u.id=?
             LIMIT 1"
        );

        if($sidebar_designation_stmt){
            mysqli_stmt_bind_param($sidebar_designation_stmt, 'i', $sidebar_login_user_id);
            mysqli_stmt_execute($sidebar_designation_stmt);
            $sidebar_designation_row = mysqli_fetch_assoc(
                mysqli_stmt_get_result($sidebar_designation_stmt)
            );
            $sidebar_designation = trim((string)($sidebar_designation_row['designation'] ?? ''));

            if($sidebar_designation !== ''){
                $sidebar_role = $sidebar_designation . ' Access';
            }
        }
    }
}

$current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$current_query = [];
parse_str((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY), $current_query);
$sidebar_is_super_admin = is_super_admin_user();
$sidebar_can_see_reports = is_admin_user()
    || (is_manager_user() && manager_has_permission('reports'));
$sidebar_can_see_admin = is_admin_user()
    || (is_manager_user() && (manager_has_permission('admin') || manager_has_permission('tools')));
$sidebar_table_system_enabled = false;

if(!$sidebar_is_super_admin && isset($conn) && $conn instanceof mysqli){
    ensure_restaurant_tables_table($conn);
    $sidebar_table_system_enabled = table_system_enabled(
        $conn,
        (int)($_SESSION['user_id'] ?? 0)
    );
}

function sidebar_is_active($href)
{
    global $current_path, $current_query;

    $href_path = parse_url($href, PHP_URL_PATH);
    if($current_path !== $href_path){
        return false;
    }

    $href_query = [];
    parse_str((string)parse_url($href, PHP_URL_QUERY), $href_query);

    foreach($href_query as $key => $value){
        if(!array_key_exists($key, $current_query) || (string)$current_query[$key] !== (string)$value){
            return false;
        }
    }

    return true;
}

function sidebar_group_active($items)
{
    foreach($items as $item){
        if(sidebar_is_active($item['href']) || ($item['href'] === app_path('sales/receive_stock.php') && (int)($item['badge'] ?? 0) > 0)){
            return true;
        }
    }

    return false;
}

function sidebar_item($href, $label, $icon = 'far fa-circle', $class = '', $badge = 0)
{
    $has_pending_receipt = $href === app_path('sales/receive_stock.php') && (int)$badge > 0;
    $active = (sidebar_is_active($href) || $has_pending_receipt) ? ' active' : '';
?>
    <li class="nav-item">
        <a href="<?= htmlspecialchars($href); ?>"
           class="nav-link<?= $active; ?> <?= htmlspecialchars($class); ?>">
            <i class="nav-icon <?= htmlspecialchars($icon); ?>"></i>
            <p><?= htmlspecialchars($label); ?><?php if((int)$badge > 0){ ?> <span class="right badge badge-danger" style="right:1.8rem"><?= (int)$badge; ?></span><?php } ?></p>
        </a>
    </li>
<?php
}

function sidebar_tree($label, $icon, $items)
{
    $open = sidebar_group_active($items);
?>
    <li class="nav-item has-treeview<?= $open ? ' menu-open' : ''; ?>">
        <a href="#"
           class="nav-link<?= $open ? ' active' : ''; ?>">
            <i class="nav-icon <?= htmlspecialchars($icon); ?>"></i>
            <p>
                <?= htmlspecialchars($label); ?>
                <i class="right fas fa-angle-left"></i>
            </p>
        </a>

        <ul class="nav nav-treeview">
            <?php foreach($items as $item){ ?>
                <?php
                sidebar_item(
                    $item['href'],
                    $item['label'],
                    $item['icon'] ?? 'far fa-circle',
                    $item['class'] ?? '',
                    $item['badge'] ?? 0
                );
                ?>
            <?php } ?>
        </ul>
    </li>
<?php
}

function sidebar_has_active_manager()
{
    global $conn;

    if(!isset($conn) || !($conn instanceof mysqli)){
        return false;
    }

    if(is_super_admin_user()){
        $sql = "SELECT COUNT(*)
                FROM users
                WHERE role='manager'
                AND status='active'";

        $stmt = mysqli_prepare($conn, $sql);
    }else{
        $sql = "SELECT COUNT(*)
                FROM users
                WHERE owner_id=?
                AND role='manager'
                AND status='active'";

        $stmt = mysqli_prepare($conn, $sql);
        $user_id = (int)($_SESSION['user_id'] ?? 0);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
    }

    if(!$stmt){
        return false;
    }

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $count = $result ? (int)mysqli_fetch_row($result)[0] : 0;

    return $count > 0;
}

$sidebar_product_items = [
    [
        'href' => app_path('product_categories/index.php'),
        'label' => 'Categories',
    ],
    [
        'href' => app_path('products/index.php'),
        'label' => 'Products',
    ],
];

if(isset($conn) && $conn instanceof mysqli && is_product_expiry_enabled($conn)){
    $sidebar_product_items[] = [
        'href' => app_path('products/expired.php'),
        'label' => 'Expired Product',
    ];
}

$sidebar_layout_items = (isset($conn) && $conn instanceof mysqli && is_admin_user() && sidebar_saved_layout_exists($conn, (int)($_SESSION['user_id'] ?? 0)))
    ? sidebar_layout_items_for_current_user(sidebar_load_layout($conn, (int)($_SESSION['user_id'] ?? 0), $project_package_labels ?? []))
    : [];

?>

<aside class="main-sidebar sidebar-dark-primary elevation-4 app-sidebar">

    <a href="<?= htmlspecialchars(app_path('dashboard.php')); ?>"
       class="brand-link app-brand">
        <img
            src="<?= htmlspecialchars($sidebar_avatar); ?>"
            alt="Account"
            class="brand-image img-circle elevation-2 app-brand-image">

        <span class="brand-text app-brand-text">
            <span class="app-brand-name">
                <?= htmlspecialchars($sidebar_name); ?>
            </span>
            <span class="app-brand-role">
                <?= htmlspecialchars($sidebar_role); ?>
            </span>
        </span>
    </a>

    <div class="sidebar">

        <nav class="mt-3">

            <ul class="nav nav-pills nav-sidebar flex-column nav-compact"
                data-widget="treeview"
                role="menu"
                data-accordion="false">

                <li class="nav-header">MAIN</li>

                <?php
                $dashboard_menu_label = is_manager_user() && manager_has_permission('dashboard')
                    ? 'Branch Dashboard'
                    : 'Dashboard';
                sidebar_item(app_path('dashboard.php'), $dashboard_menu_label, 'fas fa-home');
                if(is_manager_user()){
                    sidebar_item(app_path('staff/leave_application.php'), 'Leave Application', 'fas fa-file-medical');
                }
                ?>

                <?php
                $sidebar_staff_items = [
                    ['href' => app_path('staff/index.php'), 'label' => 'Create Staff'],
                    ['href' => app_path('staff/attendance.php'), 'label' => 'Staff Attendance'],
                    ['href' => app_path('staff/salary.php'), 'label' => 'Staff Salary'],
                    ['href' => app_path('staff/ledger.php'), 'label' => 'Other Payments'],
                ];
                if(!is_manager_user() || manager_has_permission('staff')){
                    sidebar_tree('Staff Manage', 'fas fa-user-tie', $sidebar_staff_items);
                }
                ?>

                <?php if(is_super_admin_user()){ ?>
                    <?php
                    sidebar_tree(
                        'Super Admin',
                        'fas fa-shield-alt',
                        [
                            [
                                'href' => app_path('super_admin/index.php'),
                                'label' => 'Subscription',
                            ],
                            [
                                'href' => app_path('super_admin/signup_message.php'),
                                'label' => 'Message Setup',
                            ],
                            [
                                'href' => app_path('super_admin/email_sms_settings.php'),
                                'label' => 'Settings',
                            ],
                            [
                                'href' => app_path('super_admin/company_delete_data.php'),
                                'label' => 'Company Delete Data',
                                'icon' => 'fas fa-archive',
                            ],
                            [
                                'href' => app_path('user_management/marketing.php'),
                                'label' => 'Marketing',
                                'icon' => 'fas fa-sms',
                            ],
                        ]
                    );
                    ?>
                <?php } ?>

                <li class="nav-header">OPERATIONS</li>

                <?php if(is_admin_user() || manager_has_permission('notice_publish')){ ?>
                    <?php sidebar_item(app_path('user_management/notice_publish.php'), 'Notice Publish', 'fas fa-bullhorn'); ?>
                <?php } ?>

                <?php if(is_manager_user()){ ?>
                <?php
                    if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Housing' && manager_has_permission('land_ledger')){
                        sidebar_tree('Land Ledger', 'fas fa-map-marked-alt', [
                            ['href'=>app_path('land/land_manage.php'),'label'=>'Land Manage'],
                            ['href'=>app_path('land/plot_manage.php'),'label'=>'Plot Manage'],
                            ['href'=>app_path('land/land_summary.php'),'label'=>'Land Summary'],
                        ]);
                    }
                    if(!products_module_enabled() && manager_has_permission('sales')){
                    sidebar_tree(
                        'Sales / Invoice',
                        'fas fa-file-invoice',
                        [
                            [
                                'href' => app_path('create_invoice/index.php'),
                                'label' => 'Create Invoice',
                            ],
                            [
                                'href' => app_path('create_invoice/invoice_list.php'),
                                'label' => 'Invoice List',
                            ],
                        ]
                    );
                    }
                    if(manager_has_permission('wallets')){
                        sidebar_tree('Wallets', 'fas fa-wallet', [
                            ['href' => app_path('wallets/index.php'), 'label' => 'Wallet List'],
                            ['href' => app_path('categories/index.php'), 'label' => 'Expense Categories'],
                            ['href' => app_path('moneyin/index.php'), 'label' => 'Money In'],
                            ['href' => app_path('expenses/index.php'), 'label' => 'Expenses'],
                            ['href' => app_path('transfers/index.php'), 'label' => 'Transfers'],
                            ['href' => app_path('transactions/index.php'), 'label' => 'Transactions'],
                        ]);
                    }
                    if(!products_module_enabled() && manager_has_permission('projects')){ sidebar_tree($project_package_labels['module'], 'fas fa-project-diagram', [['href'=>app_path('project_package/projects.php'),'label'=>$project_package_labels['project']],['href'=>app_path('project_package/packages.php'),'label'=>$project_package_labels['package_list']]]); }
                    if(manager_has_permission('customers')){
                        $sidebar_customer_items = [
                            ['href'=>app_path('customers/index.php'),'label'=>'Create Customer'],
                        ];
                        if(is_admin_user()){
                            $sidebar_customer_items[] = [
                                'href'=>app_path('customers/form_settings.php'),
                                'label'=>'Cus. form settings',
                            ];
                            $sidebar_customer_items[] = [
                                'href'=>app_path('user_management/customer_login_settings.php'),
                                'label'=>'Cus. Login Settings',
                            ];
                        }
                        sidebar_tree('Customer Manage', 'fas fa-users', $sidebar_customer_items);
                    }
                    if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Housing' && manager_has_permission('suppliers')){
                        sidebar_tree(supplier_display_text('Suppliers'), 'fas fa-truck', [
                            ['href' => app_path('suppliers/index.php'), 'label' => supplier_display_text('Add Supplier')],
                            ['href' => app_path('purchases/index.php'), 'label' => 'Purchases'],
                            ['href' => app_path('suppliers/supplier_payment.php'), 'label' => supplier_display_text('Supplier Due Payment')],
                        ]);
                    }
                    if(products_module_enabled()){
                        if(manager_has_permission('products')) sidebar_tree('Products', 'fas fa-boxes', $sidebar_product_items);
                        if(manager_has_permission('suppliers') && stock_can_manage_warehouse($conn)) sidebar_tree(supplier_display_text('Suppliers'), 'fas fa-truck', [['href'=>app_path('suppliers/index.php'),'label'=>supplier_display_text('Suppliers')],['href'=>app_path('purchases/index.php'),'label'=>'Purchases'],['href'=>app_path('suppliers/supplier_payment.php'),'label'=>supplier_display_text('Supplier Due Payment')]]);
                        if(manager_has_permission('warehouse') && !(in_array(project_package_company_type($conn, (int)$_SESSION['user_id']), ['Stock Product', 'Fashion house'], true) && !company_multi_branch_enabled($conn, (int)$_SESSION['user_id']))) sidebar_item(app_path('warehouse/index.php'), 'Main Warehouse', 'fas fa-warehouse');
                        if(manager_has_permission('stock_live_report') && project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Fashion house') sidebar_item(app_path('warehouse/live_report.php'), 'Stock Live Report', 'fas fa-chart-bar');
                        if(manager_has_permission('stock_sales')) {
                            $stock_sales_items = [
                                ['href'=>app_path('sales/create_invoice.php'),'label'=>'Create Invoice'],
                                ['href'=>app_path('sales/invoice_list.php'),'label'=>'Invoice List'],
                            ];
                            if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Fashion house') {
                                $stock_sales_items[] = ['href'=>app_path('sales/stock_product.php'),'label'=>'My Stock'];
                                if (company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) $stock_sales_items[] = ['href'=>app_path('sales/damaged_return.php'),'label'=>'Return Damaged'];
                            }
                            if (company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) {
                                $stock_sales_items[] = ['href'=>app_path('sales/receive_stock.php'),'label'=>'Product Req.','badge'=>$sidebar_stock_receive_pending_count];
                            }
                            if (!company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) {
                                $stock_sales_items[] = ['href'=>app_path('sales/receive_payment.php'),'label'=>'Due Payment'];
                            }
                            sidebar_tree('Sales', 'fas fa-cash-register', $stock_sales_items);
                        }
                    }
                    if(manager_has_permission('leads')){ sidebar_tree('Lead Management', 'fas fa-filter', [['href'=>app_path('lead_management/index.php?filter=lead'),'label'=>'New Lead'],['href'=>app_path('lead_management/index.php?filter=successful'),'label'=>'Qualified List'],['href'=>app_path('lead_management/index.php?filter=not_qualified'),'label'=>'Not Qualified List'],['href'=>app_path('lead_management/index.php?filter=visited'),'label'=>'Visited List'],['href'=>app_path('lead_management/index.php?filter=indecision'),'label'=>'Indecision List'],['href'=>app_path('lead_management/index.php?filter=customer'),'label'=>'Successful List']]); }
                    ?>
                <?php }else{ ?>

                <?php
                if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Housing'){
                    sidebar_tree('Land Ledger', 'fas fa-map-marked-alt', [
                        ['href'=>app_path('land/land_manage.php'),'label'=>'Land Manage'],
                        ['href'=>app_path('land/plot_manage.php'),'label'=>'Plot Manage'],
                        ['href'=>app_path('land/land_summary.php'),'label'=>'Land Summary'],
                    ]);
                }
                if(sales_module_enabled()){
                $sidebar_sales_items = [
                    [
                        'href' => app_path('sales/create_invoice.php'),
                        'label' => 'Create Invoice',
                    ],
                    [
                        'href' => app_path('sales/invoice_list.php'),
                        'label' => 'Invoice List',
                    ],
                ];
                if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Fashion house') {
                    $sidebar_sales_items[] = [
                        'href' => app_path('sales/stock_product.php'),
                        'label' => 'My Stock',
                    ];
                    if (company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) $sidebar_sales_items[] = ['href'=>app_path('sales/damaged_return.php'),'label'=>'Return Damaged'];
                }
                if (!company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) {
                    $sidebar_sales_items[] = [
                        'href' => app_path('sales/opening_due_entry.php'),
                        'label' => 'Previous Due Entry',
                    ];
                    $sidebar_sales_items[] = [
                        'href' => app_path('sales/receive_payment.php'),
                        'label' => 'Due Payment',
                    ];
                } else {
                    $sidebar_sales_items[] = [
                        'href' => app_path('sales/receive_stock.php'),
                        'label' => 'Product Req.',
                        'badge' => $sidebar_stock_receive_pending_count,
                    ];
                }
                sidebar_tree(
                    'Sales',
                    'fas fa-file-invoice',
                    $sidebar_sales_items
                );
                }

                sidebar_tree(
                    'Wallets',
                    'fas fa-wallet',
                    array_merge([
                        [
                            'href' => app_path('wallets/index.php'),
                            'label' => 'Wallet List',
                        ],
                        [
                            'href' => app_path('categories/index.php'),
                            'label' => 'Expense Categories',
                        ],
                        [
                            'href' => app_path('moneyin/index.php'),
                            'label' => 'Money In',
                        ],
                        [
                            'href' => app_path('expenses/index.php'),
                            'label' => 'Expenses',
                        ],
                        [
                            'href' => app_path('transfers/index.php'),
                            'label' => 'Transfers',
                        ],
                        [
                            'href' => app_path('transactions/index.php'),
                            'label' => 'Transactions',
                        ],
                    ])
                );

                if($sidebar_table_system_enabled){
                    sidebar_tree(
                        'Table Management',
                        'fas fa-chair',
                        [
                            [
                                'href' => app_path('table_management/index.php'),
                                'label' => 'Table List',
                            ],
                        ]
                    );

                    if(incentive_system_enabled()){
                        sidebar_tree(
                            'Incentive Management',
                            'fas fa-percent',
                            [
                                [
                                    'href' => app_path('incentive_management/index.php'),
                                    'label' => 'Staff Commission',
                                ],
                            ]
                        );
                    }
                }

                sidebar_tree(
                    'Customer Manage',
                    'fas fa-users',
                    array_merge([
                        [
                            'href' => app_path('customers/index.php'),
                            'label' => 'Create Customer',
                        ],
                    ], is_admin_user() ? [
                        [
                            'href' => app_path('customers/form_settings.php'),
                            'label' => 'Cus. form settings',
                        ],
                        [
                            'href' => app_path('user_management/customer_login_settings.php'),
                            'label' => 'Cus. Login Settings',
                        ],
                    ] : [])
                );

                if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Housing'){
                    sidebar_tree(supplier_display_text('Suppliers'), 'fas fa-truck', [
                        ['href' => app_path('suppliers/index.php'), 'label' => supplier_display_text('Add Supplier')],
                        ['href' => app_path('purchases/index.php'), 'label' => 'Purchases'],
                        ['href' => app_path('suppliers/supplier_payment.php'), 'label' => supplier_display_text('Supplier Due Payment')],
                    ]);
                }

                if(products_module_enabled()){
                sidebar_tree(
                    'Products',
                    'fas fa-boxes',
                    $sidebar_product_items
                );
                sidebar_tree(
                    supplier_display_text('Suppliers'),
                    'fas fa-truck',
                    [
                        [
                            'href' => app_path('suppliers/index.php'),
                            'label' => is_manager_user() ? supplier_display_text('Suppliers') : supplier_display_text('Add Supplier'),
                        ],
                        [
                            'href' => app_path('purchases/index.php'),
                            'label' => 'Purchases',
                        ],
                        [
                            'href' => app_path('suppliers/supplier_payment.php'),
                            'label' => supplier_display_text('Supplier Due Payment'),
                        ],
                    ]
                );

                if(!(in_array(project_package_company_type($conn, (int)$_SESSION['user_id']), ['Stock Product', 'Fashion house'], true) && !company_multi_branch_enabled($conn, (int)$_SESSION['user_id']))) sidebar_item(app_path('warehouse/index.php'), 'Main Warehouse', 'fas fa-warehouse');
                if(project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Fashion house') sidebar_item(app_path('warehouse/live_report.php'), 'Stock Live Report', 'fas fa-chart-bar');
                }

                if(!products_module_enabled()) sidebar_tree(
                    $project_package_labels['module'],
                    'fas fa-project-diagram',
                    [
                        [
                            'href' => app_path('project_package/projects.php'),
                            'label' => $project_package_labels['project'],
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('project_package/packages.php'),
                            'label' => $project_package_labels['package_list'],
                            'icon' => 'far fa-circle',
                        ],
                    ]
                );

                sidebar_tree(
                    'Lead Management',
                    'fas fa-filter',
                    [
                        [
                            'href' => app_path('lead_management/index.php?filter=lead'),
                            'label' => 'New Lead',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('lead_management/index.php?filter=successful'),
                            'label' => 'Qualified List',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('lead_management/index.php?filter=not_qualified'),
                            'label' => 'Not Qualified List',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('lead_management/index.php?filter=visited'),
                            'label' => 'Visited List',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('lead_management/index.php?filter=indecision'),
                            'label' => 'Indecision List',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('lead_management/index.php?filter=customer'),
                            'label' => 'Successful List',
                            'icon' => 'far fa-circle',
                        ],
                    ]
                );

                if(!products_module_enabled()) sidebar_tree(
                    'Sales / Invoice',
                    'fas fa-file-invoice',
                    array_merge([
                        [
                            'href' => app_path('create_invoice/index.php'),
                            'label' => 'Create Invoice',
                            'icon' => 'far fa-circle',
                        ],
                        [
                            'href' => app_path('create_invoice/invoice_list.php'),
                            'label' => 'Invoice List',
                            'icon' => 'far fa-circle',
                        ],
                    ], is_admin_user() ? [[
                            'href' => app_path('create_invoice/manage_invoice_types.php'),
                            'label' => 'Manage Payment Type',
                            'icon' => 'far fa-circle',
                        ]] : [])
                );
                ?>

                <?php } ?>

                <?php if($sidebar_can_see_reports){ ?>

                <li class="nav-header">INSIGHTS</li>

                <?php
                $sidebar_report_items = [
                    ['href' => app_path('reports/sales_report.php'), 'label' => 'Sales Report', 'icon' => 'fas fa-chart-line'],
                    ['href' => app_path('reports/category_expense.php'), 'label' => 'Expense Report', 'icon' => 'fas fa-receipt'],
                    ['href' => app_path('reports/profit_report.php'), 'label' => 'Profit Report', 'icon' => 'fas fa-coins'],
                ];
                sidebar_tree('Reports', 'fas fa-chart-bar', $sidebar_report_items);
                ?>
                <?php } ?>

                <?php if($sidebar_can_see_admin){ ?>
                    <li class="nav-header">ADMIN</li>
                    <?php
                    $sidebar_admin_items = [];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('admin_access_management')) $sidebar_admin_items[] = ['href' => app_path('user_management/index.php'), 'label' => 'Access Management', 'icon' => 'fas fa-user-cog'];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('attendance_settings')) $sidebar_admin_items[] = ['href' => app_path('staff/attendance_settings.php'), 'label' => 'Attendance Settings', 'icon' => 'fas fa-user-clock'];
                    if((is_admin_user() || manager_has_selected_admin_sidebar_permission('branch_management')) && company_multi_branch_enabled($conn, (int)$_SESSION['user_id'])) $sidebar_admin_items[] = ['href' => app_path('user_management/branch_manage.php'), 'label' => 'Branch Management', 'icon' => 'fas fa-code-branch'];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('wallet_approvals')) $sidebar_admin_items[] = ['href' => app_path('user_management/wallet_approvals.php'), 'label' => 'Wallet Approvals', 'icon' => 'fas fa-check-circle'];
                    if(is_admin_user() && project_package_company_type($conn, (int)$_SESSION['user_id']) === 'Fashion house') $sidebar_admin_items[] = ['href' => app_path('user_management/dump_approval.php'), 'label' => 'Dumps Approval', 'icon' => 'fas fa-dumpster'];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('invoice_charges')) $sidebar_admin_items[] = ['href' => app_path('user_management/invoice_charges.php'), 'label' => 'Invoice Charges', 'icon' => 'fas fa-percentage'];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('printing_option')) $sidebar_admin_items[] = ['href' => app_path('user_management/printing_option.php'), 'label' => 'Printing Option', 'icon' => 'fas fa-print'];
                    if(!is_manager_user() || manager_has_selected_admin_sidebar_permission('profit_cash_out')) $sidebar_admin_items[] = ['href' => app_path('profit_cash_out/index.php'), 'label' => 'Profit Cash Out', 'icon' => 'fas fa-coins'];
                    if(is_admin_user() || manager_has_selected_admin_sidebar_permission('sidebar_settings')) $sidebar_admin_items[] = ['href' => app_path('user_management/sidebar_settings.php'), 'label' => 'Sidebar Settings', 'icon' => 'fas fa-sliders-h'];
                    if(products_module_enabled()
                        && project_package_company_type($conn, (int)$_SESSION['user_id']) !== 'Fashion house'
                        && (is_admin_user() || (manager_has_permission('admin') && manager_has_permission('stock_sales')))) {
                        $sidebar_admin_items[] = ['href' => app_path('warehouse/sales_report.php'), 'label' => 'Sales Report', 'icon' => 'fas fa-chart-line'];
                    }
                    if($sidebar_admin_items) sidebar_tree('Admin', 'fas fa-user-cog', $sidebar_admin_items);
                    if(is_admin_user() || manager_has_permission('tools')) {
                        $sidebar_tools_items = is_super_admin_user()
                            ? [
                                ['href' => '#', 'label' => 'Export Data', 'class' => 'disabled text-muted'],
                                ['href' => '#', 'label' => 'Import Data', 'class' => 'disabled text-muted'],
                                ['href' => '#', 'label' => 'Delete All Data', 'class' => 'disabled text-muted'],
                                ['href' => app_path('tools/database_export.php'), 'label' => 'Full DB Export'],
                                ['href' => app_path('tools/database_import.php'), 'label' => 'Full DB Import', 'class' => 'text-danger'],
                            ]
                            : [
                                ['href' => app_path('tools/export.php'), 'label' => 'Export Data'],
                                ['href' => app_path('tools/import.php'), 'label' => 'Import Data'],
                                ['href' => app_path('tools/delete_data.php'), 'label' => 'Delete All Data', 'class' => 'text-danger'],
                            ];
                        sidebar_tree('Tools', 'fas fa-tools', $sidebar_tools_items);
                    }
                    ?>
                <?php } ?>

                <li class="nav-header">HELP</li>
                <?php
                $sidebar_help_items = [
                    [
                        'href' => app_path('help/video_tutorial.php'),
                        'label' => 'Video Tutorial',
                    ],
                ];
                if(is_admin_user()){
                    $sidebar_company_id = (int)($_SESSION['user_id'] ?? 0);
                    if(is_super_admin_user() || company_pricing_plan_visible($conn, $sidebar_company_id)){
                        $sidebar_help_items[] = [
                            'href' => app_path('help/pricing_plan.php'),
                            'label' => 'Pricing Plan',
                        ];
                    }
                    $sidebar_help_items[] = [
                        'href' => app_path('help/support.php'),
                        'label' => 'Support',
                    ];
                }
                sidebar_tree('Help', 'fas fa-life-ring', $sidebar_help_items);
                ?>

                <li class="nav-header">SESSION</li>

                <?php sidebar_item(app_path('logout.php'), 'Logout', 'fas fa-sign-out-alt', 'text-danger'); ?>

                <li class="nav-item sidebar-bottom-break"></li>

            </ul>

        </nav>

    </div>

</aside>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const navigation = document.querySelector('.nav-sidebar');
    if (!navigation) return;
    const sidebarLayout = <?= json_encode($sidebar_layout_items); ?>;
    const itemMap = new Map();

    function itemIdentity(item) {
        const link = item.querySelector(':scope > .nav-link');
        const label = link ? (link.querySelector('p') ? link.querySelector('p').textContent.trim().replace(/\s+/g, ' ') : '') : '';
        const href = link ? link.getAttribute('href') : '';
        return { label, href: href || '' };
    }

    function matchesLayout(identity, layout) {
        // A submenu can share its parent's label (for example, Products).
        // Match page links by URL so the child cannot replace its parent.
        if (layout.href) return identity.href === layout.href;
        const legacyLabels = { sales: 'Sales', suppliers: 'Stock In' };
        return (!identity.href || identity.href === '#')
            && (identity.label === layout.label
                || identity.label === legacyLabels[layout.id]
                || (layout.id === 'sales' && identity.label === 'Invoice')
                || (layout.id === 'stock_sales' && identity.label === 'Sales'));
    }

    function ensureTree(item) {
        if (!item.classList.contains('has-treeview')) {
            item.classList.add('has-treeview');
            const link = item.querySelector(':scope > .nav-link');
            if (link && link.getAttribute('href') !== '#') {
                link.setAttribute('href', '#');
            }
            let text = link ? link.querySelector('p') : null;
            if (text && !text.querySelector('.right')) {
                const arrow = document.createElement('i');
                arrow.className = 'right fas fa-angle-left';
                text.appendChild(arrow);
            }
        }

        let list = item.querySelector(':scope > ul.nav-treeview');
        if (!list) {
            list = document.createElement('ul');
            list.className = 'nav nav-treeview';
            item.appendChild(list);
        }
        return list;
    }

    Array.from(navigation.querySelectorAll('li.nav-item')).forEach(function (item) {
        const identity = itemIdentity(item);
        const layout = sidebarLayout.find(function (entry) { return matchesLayout(identity, entry); });
        if (layout) itemMap.set(layout.id, item);
    });

    sidebarLayout.forEach(function (entry) {
        const item = itemMap.get(entry.id);
        if (item && Number(entry.visible) === 0) {
            item.remove();
            itemMap.delete(entry.id);
        }
    });

    sidebarLayout.forEach(function (entry) {
        const item = itemMap.get(entry.id);
        if (!item || !entry.parent) return;
        const parent = itemMap.get(entry.parent);
        if (!parent || parent === item || item.contains(parent)) return;
        ensureTree(parent).appendChild(item);
    });

    const sectionHeaders = {};
    Array.from(navigation.children).forEach(function (item) {
        if (item.classList && item.classList.contains('nav-header')) {
            sectionHeaders[item.textContent.trim()] = item;
        }
    });

    ['MAIN', 'OPERATIONS', 'INSIGHTS', 'ADMIN', 'HELP', 'SESSION'].forEach(function (section) {
        let previousItem = sectionHeaders[section] || null;
        if (!previousItem) return;

        sidebarLayout
            .filter(function (entry) { return !entry.parent && entry.section === section && itemMap.has(entry.id); })
            .sort(function (a, b) { return Number(a.sort || 0) - Number(b.sort || 0); })
            .forEach(function (entry) {
                const item = itemMap.get(entry.id);
                if (!item || item.classList.contains('sidebar-bottom-break')) return;
                previousItem.insertAdjacentElement('afterend', item);
                previousItem = item;
            });
    });

    sidebarLayout.forEach(function (parentEntry) {
        const parent = itemMap.get(parentEntry.id);
        if (!parent) return;
        const list = parent.querySelector(':scope > ul.nav-treeview');
        if (!list) return;
        sidebarLayout
            .filter(function (entry) { return entry.parent === parentEntry.id && itemMap.has(entry.id); })
            .sort(function (a, b) { return Number(a.sort || 0) - Number(b.sort || 0); })
            .forEach(function (entry) {
                const child = itemMap.get(entry.id);
                if (child) list.appendChild(child);
            });
    });

    const operationsHeader = Array.from(navigation.children).find(function (item) {
        return item.classList.contains('nav-header') && item.textContent.trim() === 'OPERATIONS';
    });
    if (sidebarLayout.length) return;
    if (!operationsHeader) return;

    const orderedLabels = ['Sales / Invoice', 'Products', '<?= supplier_display_text('Suppliers'); ?>', 'Main Warehouse', 'Sales', 'Wallets', <?= json_encode($project_package_labels['module']); ?>, 'Customer Manage', 'Lead Management'];
    let previousItem = operationsHeader;

    orderedLabels.forEach(function (label) {
        const item = Array.from(navigation.children).find(function (candidate) {
            const link = candidate.querySelector(':scope > .nav-link > p');
            return link && link.textContent.trim() === label;
        });

        if (item) {
            previousItem.insertAdjacentElement('afterend', item);
            previousItem = item;
        }
    });
});
</script>

<div class="content-wrapper">

<section class="content pt-3">

<div class="container-fluid">
