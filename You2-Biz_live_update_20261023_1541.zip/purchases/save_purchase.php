<?php

require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/transaction_helper.php';
require_once '../includes/wallet_helper.php';
require_once '../includes/fifo_inventory_helper.php';
require_once '../includes/contact_unique_helper.php';
require_once '../includes/input_validation_helper.php';
require_once '../includes/product_expiry_helper.php';
require_once '../includes/product_category_helper.php';
require_once '../includes/expense_helper.php';

$user_id = $_SESSION['user_id'];

function generate_compact_purchase_no($conn)
{
    for($attempt = 0; $attempt < 20; $attempt++){
        $purchase_no = 'PUR-' . date('ymd') . '-' . random_int(1000, 9999);
        $purchase_count = 0;
        $transaction_count = 0;

        $purchase_stmt = mysqli_prepare($conn, 'SELECT COUNT(*) AS total FROM purchases WHERE purchase_no=?');
        if($purchase_stmt){
            mysqli_stmt_bind_param($purchase_stmt, 's', $purchase_no);
            mysqli_stmt_execute($purchase_stmt);
            $purchase_row = mysqli_fetch_assoc(mysqli_stmt_get_result($purchase_stmt));
            $purchase_count = (int)($purchase_row['total'] ?? 0);
            mysqli_stmt_close($purchase_stmt);
        }

        $transaction_stmt = mysqli_prepare($conn, 'SELECT COUNT(*) AS total FROM transactions WHERE txn_no=?');
        if($transaction_stmt){
            mysqli_stmt_bind_param($transaction_stmt, 's', $purchase_no);
            mysqli_stmt_execute($transaction_stmt);
            $transaction_row = mysqli_fetch_assoc(mysqli_stmt_get_result($transaction_stmt));
            $transaction_count = (int)($transaction_row['total'] ?? 0);
            mysqli_stmt_close($transaction_stmt);
        }

        if($purchase_count === 0 && $transaction_count === 0){
            return $purchase_no;
        }
    }

    return 'PUR-' . date('ymd') . '-' . random_int(10000, 99999);
}

ensure_fifo_inventory_tables($conn);
ensure_product_management_columns($conn);
if(($_SESSION['company_type'] ?? '') !== 'Housing') ensure_fifo_only_product_categories($conn, $user_id);
ensure_expense_support_tables($conn, $user_id);

if($_SERVER['REQUEST_METHOD'] != 'POST'){
    header("Location:index.php");
    exit;
}

function purchase_find_or_create_supplier($conn, $user_id)
{
    $supplier_choice = trim((string)($_POST['supplier_id'] ?? ''));

    if($supplier_choice === '__new__'){
        $supplier_name = normalize_person_name($_POST['new_supplier_name'] ?? '');
        $phone = normalize_phone_input($_POST['new_supplier_phone'] ?? '');
        $address = trim((string)($_POST['new_supplier_address'] ?? ''));
        $email = '';

        if(($error = validate_person_name($supplier_name, supplier_display_text('Supplier name'))) !== ''){
            throw new Exception($error);
        }

        if(($error = validate_phone_input($phone, 'Phone', true)) !== ''){
            throw new Exception($error);
        }

        $duplicate_message = '';
        if(
            contact_has_company_user_conflict($conn, 'phone', $phone, $user_id, $duplicate_message) ||
            contact_has_duplicate_in_table($conn, 'suppliers', supplier_display_text('Supplier'), 'phone', $phone, 0, $duplicate_message, $user_id)
        ){
            throw new Exception($duplicate_message);
        }

        $supplier_branch_column = ($_SESSION['company_type'] ?? '') === 'Restaurant & Cafe' ? 'branch_id,' : '';
        $supplier_branch_value = $supplier_branch_column !== '' ? selected_branch_id($conn, true) . ',' : '';
        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO suppliers
             (
                {$supplier_branch_column}user_id,
                supplier_name,
                phone,
                email,
                address,
                status
             )
             VALUES
             (
                {$supplier_branch_value}?,?,?,?,?, 'active'
             )"
        );

        if(!$stmt){
            throw new Exception(supplier_display_text("Supplier could not be created."));
        }

        mysqli_stmt_bind_param(
            $stmt,
            "issss",
            $user_id,
            $supplier_name,
            $phone,
            $email,
            $address
        );

        if(!mysqli_stmt_execute($stmt)){
            throw new Exception(supplier_display_text("Supplier could not be created."));
        }

        return (int)mysqli_insert_id($conn);
    }

    $supplier_id = (int)$supplier_choice;

    if($supplier_id <= 0){
        throw new Exception("Please select a supplier.");
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT id
         FROM suppliers
         WHERE id=?
         AND user_id=?
         AND status='active'
         LIMIT 1"
    );

    mysqli_stmt_bind_param($stmt, "ii", $supplier_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if(!$result || mysqli_num_rows($result) === 0){
        throw new Exception("Selected supplier not found.");
    }

    return $supplier_id;
}

function purchase_prepare_items($conn, $user_id)
{
    $product_ids = $_POST['product_id'] ?? [];
    $qtys = $_POST['qty'] ?? [];
    $prices = $_POST['cost_price'] ?? [];
    $sale_prices = $_POST['sale_price'] ?? [];
    $totals = $_POST['line_total'] ?? [];
    $new_product_names = $_POST['new_product_name'] ?? [];
    $variant_names = $_POST['variant_name'] ?? [];
    $variant_quantities = $_POST['variant_quantity'] ?? [];

    $items = [];
    $new_product_count = 0;
    $hide_purchase_product_add = in_array(
        normalize_company_type($_SESSION['company_type'] ?? ''),
        ['Stock Product', 'Fashion house'],
        true
    );

    $limit_stmt = mysqli_prepare(
        $conn,
        "SELECT u.max_products, COUNT(p.id) AS product_count
         FROM users u
         LEFT JOIN products p ON p.user_id = u.id
         WHERE u.id=?
         GROUP BY u.id, u.max_products"
    );

    mysqli_stmt_bind_param($limit_stmt, "i", $user_id);
    mysqli_stmt_execute($limit_stmt);
    $limit_info = mysqli_fetch_assoc(mysqli_stmt_get_result($limit_stmt));
    $existing_product_count = (int)($limit_info['product_count'] ?? 0);
    $max_products = (int)($limit_info['max_products'] ?? 0);

    // Purchases can only create FIFO stock products.
    if(($_SESSION['company_type'] ?? '') !== 'Housing') ensure_fifo_only_product_categories($conn, $user_id);
    if(($_SESSION['company_type'] ?? '') === 'Housing'){
        ensure_product_category_type_column($conn);
        $category_stmt = mysqli_prepare($conn, "INSERT INTO product_categories (user_id, category_name, category_type, status) SELECT ?, 'General Purchases', 'non_stock', 'active' WHERE NOT EXISTS (SELECT 1 FROM product_categories WHERE user_id=? AND status='active')");
        mysqli_stmt_bind_param($category_stmt, 'ii', $user_id, $user_id);
        mysqli_stmt_execute($category_stmt);
    }
    $stock_category_stmt = mysqli_prepare(
        $conn,
        "SELECT id FROM product_categories
         WHERE user_id=? AND status='active'
         ORDER BY id ASC
         LIMIT 1"
    );
    mysqli_stmt_bind_param($stock_category_stmt, 'i', $user_id);
    mysqli_stmt_execute($stock_category_stmt);
    $stock_category = mysqli_fetch_assoc(mysqli_stmt_get_result($stock_category_stmt));
    $stock_category_id = (int)($stock_category['id'] ?? 0);

    if($stock_category_id <= 0){
        throw new Exception('Stock Product category is not available.');
    }

    foreach($product_ids as $key => $product_choice){
        $product_choice = trim((string)$product_choice);
        $qty = (int)($qtys[$key] ?? 0);
        $price = (float)($prices[$key] ?? 0);
        $sale_price = (float)($sale_prices[$key] ?? 0);
        $total = (float)($totals[$key] ?? 0);
        $variant_name = trim((string)($variant_names[$key] ?? ''));

        if($product_choice === '' && trim((string)($new_product_names[$key] ?? '')) === ''){
            continue;
        }

        if($qty <= 0 || (float)($qtys[$key] ?? 0) !== (float)$qty){
            throw new Exception("Quantity must be at least 1.");
        }

        if(!is_finite($price) || $price < 0){
            throw new Exception("Purchase price cannot be negative.");
        }

        if(!is_finite($sale_price) || $sale_price < 0){
            throw new Exception("Sale price cannot be negative.");
        }

        if($product_choice === '__new__'){
            if($hide_purchase_product_add){
                throw new Exception('Create products from the Products menu before adding them to a purchase.');
            }
            $category_id = $stock_category_id;
            $product_name = trim((string)($new_product_names[$key] ?? ''));

            if(($error = validate_person_name($product_name, 'Product name')) !== ''){
                throw new Exception($error);
            }

            if($max_products > 0 && ($existing_product_count + $new_product_count) >= $max_products){
                throw new Exception("Product limit reached for your subscription. " . subscription_support_message());
            }

            $status = 'active';
            $sku = '';
            $expired_on = null;
            $opening_stock = 0;
            $minimum_stock = 5;

            $product_stmt = mysqli_prepare(
                $conn,
                "INSERT INTO products
                 (
                    user_id,
                    category_id,
                    product_name,
                    sku,
                    purchase_price,
                    sale_price,
                    expired_on,
                    current_stock,
                    opening_stock_quantity,
                    opening_stock_unit_cost,
                    minimum_stock,
                    status
                 )
                 VALUES
                 (
                    ?,?,?,?,?,?,?,?,?,?,?,?
                 )"
            );

            if(!$product_stmt){
                throw new Exception("Product could not be created.");
            }

            mysqli_stmt_bind_param(
                $product_stmt,
                "iissddsdddis",
                $user_id,
                $category_id,
                $product_name,
                $sku,
                $price,
                $sale_price,
                $expired_on,
                $opening_stock,
                $opening_stock,
                $price,
                $minimum_stock,
                $status
            );

            if(!mysqli_stmt_execute($product_stmt)){
                throw new Exception("Product could not be created.");
            }

            $product_id = (int)mysqli_insert_id($conn);
            $new_product_count++;
        }else{
            $product_id = (int)$product_choice;

            if($product_id <= 0){
                continue;
            }

            $product_stmt = mysqli_prepare(
                $conn,
                "SELECT p.id
                 FROM products p
                 INNER JOIN product_categories c ON c.id=p.category_id
                 WHERE p.id=?
                 AND p.user_id=?
                 AND p.status='active'
                 LIMIT 1"
            );

            mysqli_stmt_bind_param($product_stmt, "ii", $product_id, $user_id);
            mysqli_stmt_execute($product_stmt);
            $product_result = mysqli_stmt_get_result($product_stmt);

            if(!$product_result || mysqli_num_rows($product_result) === 0){
                throw new Exception("Selected product not found.");
            }
        }

        if (($_SESSION['company_type'] ?? '') === 'Restaurant & Cafe'
            && !product_uses_stock($conn, $product_id, $user_id)) {
            throw new Exception('Prepared food is non-stock and cannot be received as purchased stock.');
        }
        $product_variants = product_variant_names($conn, $product_id, $user_id);
        if(!empty($product_variants)){
            $line_variants = $variant_quantities[$key] ?? [];
            $variant_total = 0;
            foreach($product_variants as $variant){
                $variant_qty = (int)($line_variants[$variant] ?? 0);
                if($variant_qty < 0){ throw new Exception('Variant quantity cannot be negative.'); }
                if($variant_qty === 0){ continue; }
                $variant_total += $variant_qty;
                $items[] = [
                    'product_id' => $product_id,
                    'qty' => $variant_qty,
                    'price' => $price,
                    'sale_price' => $sale_price,
                    'total' => $variant_qty * $price,
                    'variant_name' => $variant,
                ];
            }
            if($variant_total <= 0 || $variant_total !== $qty){
                throw new Exception('Enter quantity for at least one variant.');
            }
            continue;
        }

        if(!product_variant_is_valid($conn, $product_id, $user_id, $variant_name)){
            throw new Exception('Select a valid variant for the selected product.');
        }

        $items[] = [
            'product_id' => $product_id,
            'qty' => $qty,
            'price' => $price,
            'sale_price' => $sale_price,
            'total' => $qty * $price,
            'variant_name' => $variant_name,
        ];
    }

    if(empty($items)){
        throw new Exception("Please add at least one product.");
    }

    return $items;
}

mysqli_begin_transaction($conn);

try{
    $supplier_id = purchase_find_or_create_supplier($conn, $user_id);
    $items = purchase_prepare_items($conn, $user_id);

    $purchase_date = date('Y-m-d');
    $grand_total = 0;
    foreach($items as $item){
        $grand_total += (float)$item['total'];
    }

    $paid_amount = (float)($_POST['paid_amount'] ?? 0);
    $payment_wallet_id = (int)($_POST['payment_wallet_id'] ?? 0);
    $payment_status = trim((string)($_POST['payment_status'] ?? 'due'));
    $notes = trim((string)($_POST['notes'] ?? ''));
    $due_amount = $grand_total - $paid_amount;

    if(!is_finite($paid_amount) || $paid_amount < 0 || $paid_amount > $grand_total){
        throw new Exception("Paid Amount must be between zero and the purchase total.");
    }
    $payment_status = $paid_amount <= 0 ? 'due' : ($paid_amount < $grand_total ? 'partial' : 'paid');
    $branch_id = ($_SESSION['company_type'] ?? '') === 'Housing'
        ? selected_branch_id($conn, true)
        : stock_purchase_location_id($conn, (int)$user_id);
    // Purchasing stock may go to Main Warehouse, but its vendor payment is
    // always paid from the Head Office wallet.
    $wallet_branch_id = in_array($_SESSION['company_type'] ?? '', ['Housing', 'Restaurant & Cafe'], true)
        ? $branch_id
        : stock_head_office_id($conn, (int)$user_id);
    if ($paid_amount > 0) stock_require_wallet($conn, $payment_wallet_id, (int)$user_id, $wallet_branch_id);

    if($paid_amount > 0){
        $wallet_balance_stmt = mysqli_prepare(
            $conn,
            "SELECT balance
             FROM wallets
             WHERE id=?
             AND user_id=?
             LIMIT 1"
        );

        mysqli_stmt_bind_param($wallet_balance_stmt, "ii", $payment_wallet_id, $user_id);
        mysqli_stmt_execute($wallet_balance_stmt);
        $wallet_balance_row = mysqli_fetch_assoc(mysqli_stmt_get_result($wallet_balance_stmt));

        if(!$wallet_balance_row){
            throw new Exception("Selected payment wallet not found.");
        }

        if($paid_amount > (float)$wallet_balance_row['balance']){
            throw new Exception("Paid amount exceeds wallet balance.");
        }
    }

    $use_compact_purchase_number = in_array(
        normalize_company_type($_SESSION['company_type'] ?? ''),
        ['Stock Product', 'Fashion house'],
        true
    );
    $purchase_no = $use_compact_purchase_number
        ? generate_compact_purchase_no($conn)
        : generate_short_unique_txn_no($conn, 'PUR', 'purchases', 'purchase_no');

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO purchases
         (
            user_id,
            branch_id,
            purchase_no,
            supplier_id,
            payment_wallet_id,
            purchase_date,
            total_amount,
            paid_amount,
            due_amount,
            payment_status,
            notes
         )
         VALUES
         (
            ?,?,?,?,?,?,?,?,?,?,?
         )"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "iisiisdddss",
        $user_id,
        $branch_id,
        $purchase_no,
        $supplier_id,
        $payment_wallet_id,
        $purchase_date,
        $grand_total,
        $paid_amount,
        $due_amount,
        $payment_status,
        $notes
    );

    mysqli_stmt_execute($stmt);
    $purchase_id = mysqli_insert_id($conn);

    foreach($items as $item){
        $product_id = (int)$item['product_id'];
        $qty = (int)$item['qty'];
        $price = (float)$item['price'];
        $total = (float)$item['total'];
        $variant_name = (string)$item['variant_name'];

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO purchase_items
             (
                purchase_id,
                product_id,
                variant_name,
                quantity,
                unit_cost,
                total_cost
             )
             VALUES
             (
                ?,?,?,?,?,?
             )"
        );

        mysqli_stmt_bind_param($stmt, "iisidd", $purchase_id, $product_id, $variant_name, $qty, $price, $total);
        mysqli_stmt_execute($stmt);

        if(($_SESSION['company_type'] ?? '') !== 'Housing'){
        if(!fifo_inventory_create_batch(
            $conn,
            $user_id,
            $product_id,
            $qty,
            $price,
            'purchase',
            $purchase_id,
            $purchase_no,
            $purchase_date
            , null, $variant_name
        )){
            throw new Exception("FIFO batch could not be created.");
        }

        $stmt = mysqli_prepare(
            $conn,
            "UPDATE products
             SET current_stock = current_stock + ?,
                 purchase_price = ?,
                 sale_price = ?
             WHERE id = ?
             AND user_id = ?"
        );

        $sale_price = (float)$item['sale_price'];
        mysqli_stmt_bind_param($stmt, "dddii", $qty, $price, $sale_price, $product_id, $user_id);
        mysqli_stmt_execute($stmt);

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO stock_transactions
             (
                user_id,
                product_id,
                transaction_type,
                quantity,
                note,
                txn_date,
                reference_no
             )
             VALUES
             (
                ?,?,
                'stock_in',
                ?,
                ?,
                ?,
                ?
             )"
        );

        $note = "Purchase";
        mysqli_stmt_bind_param($stmt, "iidsss", $user_id, $product_id, $qty, $note, $purchase_date, $purchase_no);
        mysqli_stmt_execute($stmt);
        }
    }

    if($paid_amount > 0){
        debit_wallet($conn, $payment_wallet_id, $user_id, $paid_amount);

        record_wallet_transaction(
            $conn,
            $purchase_no,
            $user_id,
            $payment_wallet_id,
            'purchase',
            $purchase_id,
            $paid_amount,
            'Purchase - ' . $purchase_no,
            $purchase_date
        );

        record_supplier_payment_expense(
            $conn,
            $user_id,
            $payment_wallet_id,
            $paid_amount,
            $purchase_date,
            supplier_display_text('Supplier Payment - ') . $purchase_no,
            'purchase_payment',
            $purchase_id
        );
    }

    mysqli_commit($conn);

    $_SESSION['success'] = "Purchase Saved Successfully.";
    header("Location:create.php?success=1");
    exit;
}catch(Exception $e){
    mysqli_rollback($conn);
    $_SESSION['error'] = $e->getMessage();
    header("Location:create.php");
    exit;
}

?>
