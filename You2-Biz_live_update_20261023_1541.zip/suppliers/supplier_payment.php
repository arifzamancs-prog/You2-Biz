<?php

require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/company_settings_helper.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
require_once '../includes/sidebar.php';

$user_id = $_SESSION['user_id'];
$is_inventory_or_fashion = in_array(
    normalize_company_type($_SESSION['company_type'] ?? ''),
    ['Stock Product', 'Fashion house'],
    true
);

$sql = "SELECT
            p.id,
            p.purchase_no,
            p.notes,
            p.purchase_date,
            p.total_amount,
            p.paid_amount,
            p.due_amount,
            p.payment_status,
            s.supplier_name,
            (
                SELECT sp.id
                FROM supplier_payments sp
                WHERE sp.purchase_id = p.id
                AND sp.user_id = p.user_id
                ORDER BY sp.id DESC
                LIMIT 1
            ) AS latest_payment_id
        FROM purchases p
        LEFT JOIN suppliers s
            ON s.id = p.supplier_id
            AND s.user_id = p.user_id
        WHERE p.user_id=?" . restaurant_catalog_scope_sql($conn, 'p') . "
        AND p.due_amount > 0
        ORDER BY p.purchase_date DESC, p.id DESC";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$purchases = [];
$total_due = 0;
$total_paid = 0;
$total_purchase = 0;

while($row = mysqli_fetch_assoc($result)){

    $purchases[] = $row;
    $total_due += (float)$row['due_amount'];
    $total_paid += (float)$row['paid_amount'];
    $total_purchase += (float)$row['total_amount'];

}

?>

<?php if(isset($_GET['success'])){ ?>

<div class="alert alert-success alert-dismissible fade show">

    <?= ($_GET['success'] ?? '') === 'deleted'
        ? supplier_display_text('Supplier due payment deleted successfully. Purchase and wallet balances were adjusted.')
        : supplier_display_text('Supplier Due Payment Saved Successfully.'); ?>

</div>

<?php } ?>

<?php if(isset($_GET['error'])){ ?>

<div class="alert alert-danger alert-dismissible fade show">

    <?= htmlspecialchars($_GET['error']); ?>

</div>

<?php } ?>

<div class="card">

    <div class="card-header">

        <h3 class="card-title">
            <?= supplier_display_text('Supplier'); ?> Due Payment
        </h3>

    </div>

    <div class="card-body">

        <style>
            #example1 .vendor-column{min-width:160px;width:18%}
            #example1 .date-column{min-width:100px;width:8%;white-space:nowrap}
            #example1 .amount-column{min-width:125px;width:12%;white-space:nowrap}
            #example1 .due-column{min-width:95px;width:8%;white-space:nowrap}
            #example1 .action-column{min-width:125px;width:125px;white-space:nowrap}
            #example1.purchase-payment-compact .action-column{min-width:0;width:1%;white-space:nowrap}
        </style>

        <table
            id="example1"
            class="table table-bordered table-striped<?= $is_inventory_or_fashion ? ' purchase-payment-compact' : '' ?>">

            <thead>

            <tr>

                <th>Purchase No</th>
                <th class="date-column">Date</th>
                <th class="vendor-column"><?= supplier_display_text('Supplier'); ?></th>
                <th class="amount-column">Total</th>
                <th class="amount-column">Paid</th>
                <th class="due-column">Due</th>
                <th>Status</th>
                <th class="action-column">Action</th>

            </tr>

            </thead>

            <tbody>

            <?php foreach($purchases as $row){ ?>

            <tr>

                <td>
                    <?= htmlspecialchars($row['purchase_no']); ?>
                    <?php if($is_inventory_or_fashion && trim((string)($row['notes'] ?? '')) !== ''){ ?>
                        <div class="small text-muted mt-1"><strong>Note:</strong> <?= nl2br(htmlspecialchars(trim((string)$row['notes']))); ?></div>
                    <?php } ?>
                </td>

                <td>
                    <?= htmlspecialchars(app_date($row['purchase_date'])); ?>
                </td>

                <td>
                    <?= htmlspecialchars($row['supplier_name'] ?: (supplier_display_text('Missing Supplier #') . (int)$row['supplier_id'])); ?>
                </td>

                <td>
                    <?= number_format($row['total_amount'],2); ?>
                </td>

                <td>
                    <?= number_format($row['paid_amount'],2); ?>
                </td>

                <td>
                    <span class="text-danger font-weight-bold">
                        <?= number_format($row['due_amount'],2); ?>
                    </span>
                </td>

                <td>

                    <?php if($row['payment_status'] == 'partial'){ ?>

                    <span class="badge badge-warning">
                        Partial
                    </span>

                    <?php }else{ ?>

                    <span class="badge badge-danger">
                        Due
                    </span>

                    <?php } ?>

                </td>

                <td class="action-column">

                    <a
                        href="supplier_payment_entry.php?id=<?= $row['id']; ?>"
                        class="btn btn-success btn-sm"
                        title="Pay">

                        <i class="fas fa-money-bill"></i>

                    </a>

                    <a
                        href="../purchases/view.php?id=<?= $row['id']; ?>"
                        class="btn btn-info btn-sm"
                        title="View">

                        <i class="fas fa-eye"></i>

                    </a>

                    <a href="../purchases/print_purchase.php?id=<?= (int)$row['id']; ?>"
                       target="_blank" rel="noopener"
                       class="btn btn-primary btn-sm" title="Print" aria-label="Print purchase invoice">
                        <i class="fas fa-print"></i>
                    </a>

                    <?php if(manager_can_modify() && (int)($row['latest_payment_id'] ?? 0) > 0){ ?>
                        <a
                            href="delete_payment.php?id=<?= (int)$row['latest_payment_id']; ?>&purchase_id=<?= (int)$row['id']; ?>"
                            class="btn btn-danger btn-sm"
                            title="Delete"
                            onclick="return confirm('Delete the latest <?= supplier_display_text('supplier'); ?> due payment for this purchase? Wallet balance and purchase due will be adjusted.');">

                            <i class="fas fa-trash"></i>

                        </a>
                    <?php } ?>

                </td>

            </tr>

            <?php } ?>

            </tbody>

            <tfoot>

            <tr>

                <th colspan="3" class="text-right">
                    Total
                </th>
                <th><?= number_format($total_purchase,2); ?></th>
                <th><?= number_format($total_paid,2); ?></th>
                <th><?= number_format($total_due,2); ?></th>
                <th colspan="2"></th>

            </tr>

            </tfoot>

        </table>

    </div>

</div>

<?php
require_once '../includes/footer.php';
?>
