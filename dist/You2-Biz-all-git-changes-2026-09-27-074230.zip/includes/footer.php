        </div>
    </section>
</div>

<footer class="main-footer">

    <strong>
You2 Biz &copy; <?= date('Y'); ?>
    </strong>

</footer>

</div>

<?php $app_root_path = function_exists('app_root_path') ? app_root_path() : ''; ?>

<!-- jQuery -->
<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/jquery/jquery.min.js'); ?>"></script>

<!-- Bootstrap -->
<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

<!-- DataTables -->
<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/datatables/jquery.dataTables.min.js'); ?>"></script>

<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'); ?>"></script>

<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js'); ?>"></script>

<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js'); ?>"></script>

<!-- Select2 -->
<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/plugins/select2/js/select2.full.min.js'); ?>"></script>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- AdminLTE -->
<script src="<?= htmlspecialchars(($app_root_path === '' ? '' : $app_root_path) . '/adminlte/dist/js/adminlte.min.js'); ?>"></script>

<script>

$(function () {

    $("table.table").each(function(){

        if(!$(this).parent().hasClass("table-responsive")){

            $(this).wrap(
                '<div class="table-responsive"></div>'
            );

        }

    });

    if($("#example1").length){

        var example1Responsive = !$("#example1").is("[data-desktop-table]");

        $("#example1").DataTable({

            "responsive": example1Responsive,
            "autoWidth": false,
            "order": []

        });

    }

});

</script>
<?php if (function_exists('is_manager_user') && is_manager_user()) { ?>
<script>
(function () {
    const removeDeleteControls = function (root) {
        (root || document).querySelectorAll('a, button, input[type="submit"], input[type="button"]').forEach(function (control) {
            const href = (control.getAttribute('href') || '').toLowerCase();
            const label = [control.getAttribute('title'), control.getAttribute('name'), control.getAttribute('value'), control.dataset.action, control.dataset.staffAction, control.dataset.formAction].filter(Boolean).join(' ').toLowerCase();
            const isDeleteControl = control.dataset.staffAction === 'delete'
                || control.dataset.action === 'delete'
                || control.dataset.formAction === 'delete'
                || /(^|\/)delete[^/]*\.php(?:\?|$)/.test(href)
                || /\b(delete|remove|destroy)\b/.test(label);
            if (isDeleteControl) control.remove();
        });
    };
    removeDeleteControls(document);
    new MutationObserver(function (changes) {
        changes.forEach(function (change) { change.addedNodes.forEach(function (node) { if (node.nodeType === 1) removeDeleteControls(node); }); });
    }).observe(document.body, {childList: true, subtree: true});
})();
</script>
<?php } ?>
<?php
if (isset($page_script)) {
    echo $page_script;
}
?>

<style>
@media print {
    .report-print-heading {
        position: relative !important;
        display: block !important;
        text-align: left !important;
        border-top: 7px solid #1677e8 !important;
        border-bottom: 1px solid #ccd8e8 !important;
        padding: 13px 0 9px !important;
        margin: 0 0 12px !important;
    }
    .report-print-heading .print-brand {
        color: #0b2e59 !important;
        font-size: 19px !important;
        font-weight: 800 !important;
        letter-spacing: 1.4px !important;
        line-height: 1.1 !important;
    }
    .report-print-heading .print-brand span {
        color: #1677e8 !important;
        font-weight: 500 !important;
    }
    .report-print-heading .print-document-title {
        color: #14213d !important;
        font-size: 15px !important;
        font-weight: 700 !important;
        letter-spacing: 1.1px !important;
        margin-top: 5px !important;
        text-transform: uppercase !important;
    }
    .report-print-heading .print-report-meta {
        border-top: 1px solid #e2e9f2 !important;
        color: #5d6b82 !important;
        display: flex !important;
        font-size: 9px !important;
        justify-content: space-between !important;
        margin-top: 7px !important;
        padding-top: 6px !important;
    }
    .report-print-heading ~ .row .small-box {
        border-top: 3px solid #1677e8 !important;
        padding: 4px !important;
    }
    .report-print-heading ~ .row .small-box h3 { font-size: 20px !important; }
    .report-print-heading ~ .card .card-header .card-title,
    .report-print-heading ~ .row .card-header .card-title {
        color: #12375d !important;
        font-size: 12px !important;
        font-weight: 700 !important;
    }
    .report-print-heading ~ .card .card-body > div[style],
    .report-print-heading ~ .row .card-body > div[style] { height: 210px !important; }
    .report-print-heading ~ .card,
    .report-print-heading ~ .row .card { page-break-inside: avoid !important; }
    .report-print-heading ~ .card tfoot th,
    .report-print-heading ~ .card tfoot td,
    .report-print-heading ~ .row tfoot th,
    .report-print-heading ~ .row tfoot td {
        background: #edf4fb !important;
        font-weight: 700 !important;
    }
    .report-print-heading ~ .card:last-child { margin-bottom: 0 !important; }
    .report-print-heading ~ .card:last-child:after,
    .report-print-heading ~ .row:last-child:after {
        border-top: 1px solid #dce5ef !important;
        color: #6a7890 !important;
        content: "This report is system generated by You2 Technologies" !important;
        display: block !important;
        font-size: 8px !important;
        margin-top: 8px !important;
        padding-top: 5px !important;
        text-align: center !important;
    }
}
</style>

<?php if(function_exists('is_manager_user') && is_manager_user()){
    $footer_restricted_selectors = [
            '[title*="Delete" i]',
            '[aria-label*="Delete" i]',
            'a[href*="delete" i]',
            'a[href*="del=" i]',
            'input[type="submit"][value*="Delete" i]',
            'button[value*="delete" i]',
            'button[name="action"][value*="delete" i]',
        ];
?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const restrictedSelector = <?= json_encode($footer_restricted_selectors); ?>.join(',');

    document.querySelectorAll(restrictedSelector).forEach(function (element) {
        element.remove();
    });
});
</script>
<?php } ?>

<?php if (function_exists('stock_csrf_token')) { ?>
<script>
(function () {
    const token = <?= json_encode(stock_csrf_token()); ?>;
    const localStockUrl = function (value) {
        const url = new URL(value || location.href, location.href);
        return url.origin === location.origin && /\/(sales|products|product_categories|purchases|suppliers|warehouse)\//.test(url.pathname);
    };
    document.querySelectorAll('form').forEach(function (form) {
        if (form.method.toLowerCase() !== 'post' || !localStockUrl(form.action)) return;
        if (!form.querySelector('[name="stock_csrf"]')) {
            const input = document.createElement('input');
            input.type = 'hidden'; input.name = 'stock_csrf'; input.value = token;
            form.appendChild(input);
        }
    });
    if (window.jQuery) $.ajaxPrefilter(function (options) {
        if ((options.type || 'GET').toUpperCase() !== 'POST' || !localStockUrl(options.url)) return;
        if (options.data instanceof FormData) options.data.set('stock_csrf', token);
        else if (typeof options.data === 'string') options.data += '&stock_csrf=' + encodeURIComponent(token);
        else options.data = Object.assign({}, options.data, {stock_csrf: token});
    });
})();
</script>
<?php } ?>
</body>
</html>
