<?php

require_once __DIR__ . '/booking_invoice_helper.php';

function ensure_customer_portal_columns($conn)
{
    $columns = [
        'portal_password' => "ALTER TABLE customers ADD COLUMN portal_password VARCHAR(255) NULL AFTER email",
        'portal_password_changed' => "ALTER TABLE customers ADD COLUMN portal_password_changed TINYINT(1) NOT NULL DEFAULT 0 AFTER portal_password",
        'photo' => "ALTER TABLE customers ADD COLUMN photo VARCHAR(255) NULL AFTER portal_password_changed",
    ];

    foreach($columns as $column => $sql){
        $result = mysqli_query($conn, "SHOW COLUMNS FROM customers LIKE '" . mysqli_real_escape_string($conn, $column) . "'");
        if($result && mysqli_num_rows($result) === 0){
            mysqli_query($conn, $sql);
        }
    }
}

function ensure_customer_access_table($conn)
{
    mysqli_query(
        $conn,
        "CREATE TABLE IF NOT EXISTS customer_access_accounts (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            customer_id BIGINT UNSIGNED NOT NULL,
            username VARCHAR(120) NOT NULL,
            password VARCHAR(255) NOT NULL,
            status ENUM('active','inactive') NOT NULL DEFAULT 'active',
            last_login DATETIME NULL,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_customer_access_username (user_id, username),
            UNIQUE KEY uniq_customer_access_customer (user_id, customer_id),
            KEY idx_customer_access_login (username, status)
        )"
    );
}

function ensure_invoice_request_table($conn)
{
    mysqli_query(
        $conn,
        "CREATE TABLE IF NOT EXISTS invoice_requests (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            customer_id BIGINT UNSIGNED NOT NULL,
            note TEXT NULL,
            photo VARCHAR(255) NOT NULL,
            status ENUM('pending','completed') NOT NULL DEFAULT 'pending',
            completed_invoice_id BIGINT UNSIGNED NULL,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME NULL,
            KEY idx_invoice_request_pending (user_id, status, created_at),
            KEY idx_invoice_request_customer (customer_id, status)
        )"
    );
    // Supports existing installations created before the rejected state existed.
    mysqli_query($conn, "ALTER TABLE invoice_requests MODIFY status ENUM('pending','completed','rejected') NOT NULL DEFAULT 'pending'");
}

function invoice_request_photo_url($photo)
{
    $filename = basename(trim((string)$photo));
    if($filename === ''){
        return '';
    }

    $path = dirname(__DIR__) . '/uploads/invoice_requests/' . $filename;
    return is_file($path) ? '../uploads/invoice_requests/' . rawurlencode($filename) : '';
}

function customer_portal_upload_invoice_request_photo($file, &$message = '')
{
    if(!isset($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE){
        $message = 'Please choose a photo.';
        return false;
    }
    if(($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK){
        $message = 'Photo upload failed.';
        return false;
    }
    if((int)($file['size'] ?? 0) > 5 * 1024 * 1024){
        $message = 'Photo size must be 5MB or less.';
        return false;
    }

    $info = @getimagesize($file['tmp_name']);
    if(!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)){
        $message = 'Please upload a JPG, PNG or WEBP image.';
        return false;
    }

    // On installations without GD, the browser compressor sends an already
    // compressed image. Accept only a file that is safely within the limit.
    if(!extension_loaded('gd')){
        if((int)$file['size'] > 50 * 1024){
            $message = 'Image compression is still in progress. Please wait a moment and submit again.';
            return false;
        }
        $directory = dirname(__DIR__) . '/uploads/invoice_requests';
        if(!is_dir($directory) && !mkdir($directory, 0775, true)){
            $message = 'Photo storage could not be created.';
            return false;
        }
        $extension = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$info[2]];
        $filename = 'invoice_request_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
        if(!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)){
            $message = 'Photo could not be saved.';
            return false;
        }
        return $filename;
    }

    $source = $info[2] === IMAGETYPE_JPEG ? @imagecreatefromjpeg($file['tmp_name']) : ($info[2] === IMAGETYPE_PNG ? @imagecreatefrompng($file['tmp_name']) : @imagecreatefromwebp($file['tmp_name']));
    if(!$source){
        $message = 'Photo could not be processed.';
        return false;
    }

    $source_width = imagesx($source);
    $source_height = imagesy($source);
    $directory = dirname(__DIR__) . '/uploads/invoice_requests';
    if(!is_dir($directory) && !mkdir($directory, 0775, true)){
        imagedestroy($source);
        $message = 'Photo storage could not be created.';
        return false;
    }

    $filename = 'invoice_request_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.jpg';
    $path = $directory . '/' . $filename;
    $saved = false;
    foreach([1000, 800, 640, 480, 360, 280, 220, 180, 140, 110] as $max_side){
        $scale = min(1, $max_side / max($source_width, $source_height));
        $width = max(1, (int)round($source_width * $scale));
        $height = max(1, (int)round($source_height * $scale));
        $target = imagecreatetruecolor($width, $height);
        $white = imagecolorallocate($target, 255, 255, 255);
        imagefill($target, 0, 0, $white);
        imagecopyresampled($target, $source, 0, 0, 0, 0, $width, $height, $source_width, $source_height);
        foreach([82, 72, 62, 52, 42, 32, 22, 14] as $quality){
            if(imagejpeg($target, $path, $quality) && is_file($path) && filesize($path) <= 50 * 1024){
                $saved = true;
                imagedestroy($target);
                break 2;
            }
        }
        imagedestroy($target);
    }
    imagedestroy($source);

    if(!$saved){
        // Some shared-host GD builds report an unreliable output size even
        // after successfully writing the final tiny JPEG. Keep that final
        // compressed file rather than blocking the customer's request.
        if(is_file($path) && filesize($path) > 0){
            return $filename;
        }
        if(is_file($path)) unlink($path);
        $message = 'Photo could not be processed. Please try another image.';
        return false;
    }

    return $filename;
}

function normalize_customer_access_username($username)
{
    $username = strtolower(trim((string)$username));
    return preg_replace('/[^a-z0-9._-]/', '', $username);
}

function build_customer_access_username($username, $owner_id)
{
    return normalize_customer_access_username($username) . '@c' . (int)$owner_id;
}

function display_customer_access_username_base($username, $owner_id)
{
    $username = trim((string)$username);
    $suffix = '@c' . (int)$owner_id;

    if($suffix !== '@c0' && substr($username, -strlen($suffix)) === $suffix){
        return substr($username, 0, -strlen($suffix));
    }

    return $username;
}

function customer_portal_logged_in()
{
    return isset($_SESSION['customer_portal_id'], $_SESSION['customer_portal_user_id']);
}

function require_customer_portal_login()
{
    if(!customer_portal_logged_in()){
        header('Location: ../login.php');
        exit;
    }
}

function customer_portal_current_customer($conn)
{
    ensure_customer_portal_columns($conn);

    $customer_id = (int)($_SESSION['customer_portal_id'] ?? 0);
    $user_id = (int)($_SESSION['customer_portal_user_id'] ?? 0);

    if($customer_id <= 0 || $user_id <= 0){
        return null;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT *
         FROM customers
         WHERE id=?
         AND user_id=?
         AND status='active'
         LIMIT 1"
    );

    if(!$stmt){
        return null;
    }

    mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
    mysqli_stmt_execute($stmt);
    $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    return $customer ?: null;
}

function customer_photo_url($photo)
{
    $photo = trim((string)$photo);

    if($photo === ''){
        return '';
    }

    $photo = str_replace('\\', '/', $photo);

    if(str_starts_with($photo, 'uploads/')){
        return '../' . implode('/', array_map('rawurlencode', explode('/', $photo)));
    }

    $filename = basename($photo);
    $root = dirname(__DIR__);

    if(is_file($root . '/uploads/customers/' . $filename)){
        return '../uploads/customers/' . rawurlencode($filename);
    }

    if(is_file($root . '/uploads/avatars/' . $filename)){
        return '../uploads/avatars/' . rawurlencode($filename);
    }

    return '';
}

function customer_portal_upload_photo($file, &$message = '')
{
    if(!isset($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE){
        return '';
    }

    if(($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK){
        $message = 'Photo upload failed.';
        return false;
    }

    if((int)($file['size'] ?? 0) > 2 * 1024 * 1024){
        $message = 'Photo size must be 2MB or less.';
        return false;
    }

    $info = getimagesize($file['tmp_name']);
    if(!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)){
        $message = 'Please upload JPG, PNG or WEBP photo.';
        return false;
    }

    if(!extension_loaded('gd')){
        $message = 'Photo resize needs PHP GD extension.';
        return false;
    }

    $source = null;
    if($info[2] === IMAGETYPE_JPEG){
        $source = imagecreatefromjpeg($file['tmp_name']);
    }elseif($info[2] === IMAGETYPE_PNG){
        $source = imagecreatefrompng($file['tmp_name']);
    }elseif($info[2] === IMAGETYPE_WEBP){
        $source = imagecreatefromwebp($file['tmp_name']);
    }

    if(!$source){
        $message = 'Photo could not be processed.';
        return false;
    }

    $width = imagesx($source);
    $height = imagesy($source);
    $side = min($width, $height);
    $src_x = (int)(($width - $side) / 2);
    $src_y = (int)(($height - $side) / 2);

    $target = imagecreatetruecolor(250, 250);
    imagealphablending($target, true);
    imagesavealpha($target, true);
    imagecopyresampled($target, $source, 0, 0, $src_x, $src_y, 250, 250, $side, $side);

    $dir = dirname(__DIR__) . '/uploads/customers';
    if(!is_dir($dir)){
        mkdir($dir, 0775, true);
    }

    $filename = 'customer_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.jpg';
    $path = $dir . '/' . $filename;

    $saved = imagejpeg($target, $path, 88);
    imagedestroy($source);
    imagedestroy($target);

    if(!$saved){
        $message = 'Photo could not be saved.';
        return false;
    }

    return $filename;
}

function customer_portal_ledger_rows($conn, $user_id, $customer_id)
{
    $ledger = [];
    $invoice_types = booking_invoice_types($conn, $user_id, false);

    $stmt = mysqli_prepare($conn, "SELECT invoice_date, invoice_no, total_amount FROM invoices WHERE customer_id=? AND user_id=? AND accounting_status='posted'");
    mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while($result && $row = mysqli_fetch_assoc($result)){
        $ledger[] = [
            'date' => $row['invoice_date'],
            'type' => 'Invoice',
            'reference' => $row['invoice_no'],
            'debit' => (float)$row['total_amount'],
            'credit' => 0,
        ];
    }

    $stmt = mysqli_prepare($conn, "SELECT payment_date, amount, note FROM customer_payments WHERE customer_id=? AND user_id=?");
    mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while($result && $row = mysqli_fetch_assoc($result)){
        $ledger[] = [
            'date' => $row['payment_date'],
            'type' => 'Payment',
            'reference' => $row['note'] ?: 'Payment',
            'debit' => 0,
            'credit' => (float)$row['amount'],
        ];
    }

    $stmt = mysqli_prepare($conn, "SELECT entry_date, due_no, amount FROM customer_opening_dues WHERE customer_id=? AND user_id=?");
    if($stmt){
        mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        while($result && $row = mysqli_fetch_assoc($result)){
            $ledger[] = [
                'date' => $row['entry_date'],
                'type' => 'Previous Due',
                'reference' => $row['due_no'],
                'debit' => (float)$row['amount'],
                'credit' => 0,
            ];
        }
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT
            bi.invoice_date,
            bi.invoice_no,
            COALESCE(NULLIF(bi.total_price, 0), pk.price, bi.amount) AS package_price,
            bi.invoice_type
         FROM booking_invoices bi
         LEFT JOIN packages pk
            ON pk.id=bi.package_id
            AND pk.user_id=bi.user_id
         WHERE bi.customer_id=?
         AND bi.user_id=?
         AND bi.status='confirmed'"
    );
    if($stmt){
        mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        while($result && $row = mysqli_fetch_assoc($result)){
            $invoice_type_key = normalize_booking_invoice_type($row['invoice_type'] ?? '', $invoice_types);
            $is_refund = booking_invoice_behavior($conn, $user_id, $invoice_type_key) === 'expense';
            $ledger[] = [
                'date' => $row['invoice_date'],
                'type' => $row['invoice_type'] ?: 'Booking Invoice',
                'reference' => $row['invoice_no'],
                'debit' => (!$is_refund && booking_invoice_establishes_total($conn, $user_id, $invoice_type_key)) ? (float)$row['package_price'] : 0,
                'credit' => 0,
            ];
        }
    }

    usort($ledger, function($a, $b){
        return strcmp((string)$a['date'], (string)$b['date']);
    });

    return $ledger;
}

function customer_portal_admin_style_ledger_rows($conn, $user_id, $customer_id, $invoice_types = [])
{
    $ledger = [];

    $stmt = mysqli_prepare(
        $conn,
        "SELECT
            t.id,
            t.txn_date,
            t.transaction_type,
            t.amount,
            bi.invoice_no,
            bi.invoice_type,
            bi.notes AS invoice_note,
            bi.invoice_date,
            COALESCE(NULLIF(bi.total_price, 0), pk.price, bi.amount) AS package_price,
            p.project_name,
            pk.package_name,
            w.wallet_name
         FROM transactions t
         INNER JOIN booking_invoices bi
            ON bi.id=t.reference_id
            AND bi.user_id=t.user_id
         LEFT JOIN projects p
            ON p.id=bi.project_id
            AND p.user_id=bi.user_id
         LEFT JOIN packages pk
            ON pk.id=bi.package_id
            AND pk.user_id=bi.user_id
         LEFT JOIN wallets w
            ON w.id=t.wallet_id
            AND w.user_id=t.user_id
         WHERE bi.customer_id=?
         AND bi.user_id=?
         AND bi.status='confirmed'
         AND t.transaction_type IN ('invoice_income', 'invoice_expense')
         ORDER BY t.txn_date, t.id"
    );

    if($stmt){
        mysqli_stmt_bind_param($stmt, 'ii', $customer_id, $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        while($result && $row = mysqli_fetch_assoc($result)){
            $is_refund = $row['transaction_type'] === 'invoice_expense';
            $invoice_type_key = normalize_booking_invoice_type($row['invoice_type'] ?? '', $invoice_types);
            $project_details = trim(
                (string)($row['project_name'] ?? '') .
                (($row['project_name'] ?? '') !== '' && ($row['package_name'] ?? '') !== '' ? ' - ' : '') .
                (string)($row['package_name'] ?? '')
            );

            $ledger[] = [
                'trx_date' => $row['txn_date'],
                'invoice_no' => trim((string)$row['invoice_no']),
                'wallet_name' => (string)($row['wallet_name'] ?? ''),
                'payment_type' => function_exists('booking_invoice_type_label')
                    ? booking_invoice_type_label($row['invoice_type'] ?? '', $invoice_types)
                    : (string)($row['invoice_type'] ?? ''),
                'note' => trim((string)($row['invoice_note'] ?? '')) !== '' ? (string)$row['invoice_note'] : 'confirmed',
                'project_details' => $project_details,
                'booking_date' => $row['invoice_date'],
                'total_amount' => (!$is_refund && booking_invoice_establishes_total($conn, $user_id, $invoice_type_key)) ? (float)$row['package_price'] : 0,
                'sort_order' => $is_refund ? 3 : 2,
                'reference_id' => (int)$row['id'],
                'debit' => $is_refund ? (float)$row['amount'] : 0,
                'credit' => $is_refund ? 0 : (float)$row['amount'],
            ];
        }
    }

    usort($ledger, function($a, $b){
        $date_compare = strtotime($a['trx_date']) - strtotime($b['trx_date']);
        if($date_compare !== 0){
            return $date_compare;
        }
        if($a['sort_order'] !== $b['sort_order']){
            return $a['sort_order'] - $b['sort_order'];
        }
        return $a['reference_id'] - $b['reference_id'];
    });

    return $ledger;
}

function customer_portal_group_ledger_rows($ledger)
{
    $groups = [];

    foreach($ledger as $row){
        $invoice_no = trim((string)($row['invoice_no'] ?? ''));
        $project_details = trim((string)($row['project_details'] ?? ''));
        $booking_date = trim((string)($row['booking_date'] ?? ''));
        $group_key = $invoice_no !== ''
            ? 'invoice-' . md5($invoice_no)
            : 'entry-' . ($row['reference_id'] ?? count($groups));

        if(!isset($groups[$group_key])){
            $groups[$group_key] = [
                'project_details' => $project_details !== '' ? $project_details : '-',
                'booking_date' => $booking_date !== '' && function_exists('app_date') ? app_date($booking_date) : ($booking_date ?: '-'),
                'booking_dates' => [],
                'total_amount' => 0,
                'total_paid' => 0,
                'total_due' => 0,
                'latest_time' => strtotime($row['trx_date']) ?: 0,
                'rows' => [],
            ];
        }

        $row_total_amount = (float)($row['total_amount'] ?? 0);
        if($row_total_amount > 0){
            $groups[$group_key]['total_amount'] += $row_total_amount;
        }

        if($booking_date !== ''){
            $groups[$group_key]['booking_dates'][$booking_date] = function_exists('app_date') ? app_date($booking_date) : $booking_date;
        }

        $groups[$group_key]['total_paid'] += ((float)$row['credit'] - (float)$row['debit']);
        $groups[$group_key]['latest_time'] = max((int)$groups[$group_key]['latest_time'], strtotime($row['trx_date']) ?: 0);
        $groups[$group_key]['rows'][] = $row;
    }

    foreach($groups as &$group){
        $running_paid = 0;
        $rows = [];

        if(!empty($group['booking_dates'])){
            $group['booking_date'] = implode(', ', array_values($group['booking_dates']));
        }

        foreach($group['rows'] as $row){
            $running_paid += ((float)$row['credit'] - (float)$row['debit']);
            $row['due'] = max(0, (float)$group['total_amount'] - $running_paid);
            $rows[] = $row;
        }

        $group['rows'] = array_reverse($rows);
        $group['total_due'] = max(0, (float)$group['total_amount'] - (float)$group['total_paid']);
    }
    unset($group);

    foreach($groups as $key => $group){
        if(trim((string)$group['project_details']) !== '-' && (float)$group['total_amount'] <= 0){
            unset($groups[$key]);
        }
    }

    uasort($groups, function($a, $b){
        return ((int)$b['latest_time']) <=> ((int)$a['latest_time']);
    });

    return $groups;
}
