<?php
require_once '../includes/auth.php'; require_once '../includes/db.php'; require_once '../includes/staff_helper.php'; require_once '../includes/branch_helper.php';
ensure_staff_table($conn); $user_id=(int)$_SESSION['user_id']; ensure_head_office_branch($conn, $user_id);
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'ajax_staff_action'){
 header('Content-Type: application/json');
 $id=(int)($_POST['staff_id'] ?? 0); $staff_action=$_POST['staff_action'] ?? '';
 $staff_stmt=mysqli_prepare($conn,"SELECT id,status FROM staff WHERE id=? AND user_id=? LIMIT 1"); mysqli_stmt_bind_param($staff_stmt,'ii',$id,$user_id); mysqli_stmt_execute($staff_stmt); $staff_row=mysqli_fetch_assoc(mysqli_stmt_get_result($staff_stmt));
 if(!$staff_row){ http_response_code(404); echo json_encode(['success'=>false,'message'=>'Staff not found.']); exit; }
 if($staff_action==='toggle'){
  if(!manager_can_modify()){ http_response_code(403); echo json_encode(['success'=>false,'message'=>'Permission denied.']); exit; }
  $new_status=$staff_row['status']==='active' ? 'inactive' : 'active'; $update=mysqli_prepare($conn,"UPDATE staff SET status=? WHERE id=? AND user_id=?"); mysqli_stmt_bind_param($update,'sii',$new_status,$id,$user_id); mysqli_stmt_execute($update); echo json_encode(['success'=>true,'status'=>$new_status]); exit;
 }
 if($staff_action==='delete'){
  if(!manager_can_modify() || staff_has_transactions($conn,$id)){ http_response_code(422); echo json_encode(['success'=>false,'message'=>'This staff cannot be deleted.']); exit; }
  $delete=mysqli_prepare($conn,"DELETE FROM staff WHERE id=? AND user_id=?"); mysqli_stmt_bind_param($delete,'ii',$id,$user_id); mysqli_stmt_execute($delete); echo json_encode(['success'=>true,'deleted'=>true]); exit;
 }
 http_response_code(422); echo json_encode(['success'=>false,'message'=>'Invalid action.']); exit;
}
if(isset($_GET['toggle']) && manager_can_modify()){
 $id=(int)$_GET['toggle']; $stmt=mysqli_prepare($conn,"UPDATE staff SET status=IF(status='active','inactive','active') WHERE id=? AND user_id=?"); mysqli_stmt_bind_param($stmt,'ii',$id,$user_id); mysqli_stmt_execute($stmt); header('Location:index.php'); exit;
}
$stmt=mysqli_prepare($conn,"SELECT s.*, COALESCE(NULLIF(s.photo,''), NULLIF(u.avatar,'')) AS display_photo, COALESCE(NULLIF(b.branch_name,''), 'Head Office') AS branch_name FROM staff s LEFT JOIN users u ON u.staff_id=s.id AND u.owner_id=s.user_id AND u.role='manager' LEFT JOIN branches b ON b.id=s.branch_id AND b.user_id=s.user_id WHERE s.user_id=? ORDER BY s.id DESC"); mysqli_stmt_bind_param($stmt,'i',$user_id); mysqli_stmt_execute($stmt); $staff=mysqli_stmt_get_result($stmt);
require_once '../includes/header.php'; require_once '../includes/navbar.php'; require_once '../includes/sidebar.php'; ?>
<style>.staff-photo-preview{padding:0;border:0;background:transparent;cursor:zoom-in;line-height:0}.staff-photo-preview img{transition:transform .15s ease}.staff-photo-preview:hover img{transform:scale(1.08)}</style>
<div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-users mr-2"></i>Staff List</h3><?php if(can_create_staff()){ ?><div class="card-tools"><a href="create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Create Staff</a></div><?php } ?></div><div class="card-body"><table id="example1" class="table table-bordered table-striped"><thead><tr><th>SL</th><th>Photo</th><th>Staff ID</th><th>Staff Information</th><th>Address</th><th>Designation</th><th>Branch Name</th><th>Salary</th><th>Action</th></tr></thead><tbody><?php while($row=mysqli_fetch_assoc($staff)){ $used=staff_has_transactions($conn,$row['id']); $photo_url=staff_photo_public_url($row['display_photo'] ?? $row['photo'] ?? ''); ?><tr data-staff-id="<?= (int)$row['id'] ?>"><td class="staff-sl"></td><td><?php if($photo_url !== ''){ ?><button type="button" class="staff-photo-preview" data-photo-src="<?= htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8') ?>" data-photo-alt="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?>" title="Click to view larger photo"><img src="<?=htmlspecialchars($photo_url)?>" alt="<?= htmlspecialchars($row['name']) ?>" style="width:48px;height:48px;object-fit:cover;border-radius:50%;"></button><?php }else{ ?><span class="text-muted">No photo</span><?php } ?></td><td><?=htmlspecialchars($row['staff_code'] ?: staff_code_from_id($row['id']))?><br><span class="badge staff-status-badge badge-<?=$row['status']==='active'?'success':'secondary'?>"><?=htmlspecialchars($row['status'])?></span></td><td><strong><?= htmlspecialchars($row['name']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($row['email'] ?? '-') ?></small><br><small class="text-muted"><?= htmlspecialchars($row['phone'] ?? '-') ?></small></td><td><?=htmlspecialchars($row['address'] ?? '')?></td><td><?=htmlspecialchars($row['designation'] ?? '')?></td><td><?= htmlspecialchars($row['branch_name']) ?></td><td>BDT <?=number_format((float)($row['salary'] ?? 0), 2)?></td><td><a class="btn btn-info btn-sm" href="profile.php?id=<?=$row['id']?>" title="Ledger"><i class="fas fa-book"></i></a><?php if(manager_can_modify()){ ?><button type="button" class="btn btn-sm staff-ajax-action staff-toggle-action btn-<?=$row['status']==='active'?'secondary':'success'?>" data-staff-id="<?= (int)$row['id'] ?>" data-staff-action="toggle" title="<?=$row['status']==='active'?'Make Inactive':'Make Active'?>"><i class="fas <?=$row['status']==='active'?'fa-toggle-off':'fa-toggle-on'?>"></i></button><a class="btn btn-warning btn-sm" href="edit.php?id=<?=$row['id']?>" title="Edit"><i class="fas fa-edit"></i></a><?php if(!$used){ ?><button type="button" class="btn btn-danger btn-sm staff-ajax-action" data-staff-id="<?= (int)$row['id'] ?>" data-staff-action="delete" title="Delete"><i class="fas fa-trash"></i></button><?php }else{ ?><button type="button" class="btn btn-secondary btn-sm" disabled title="This staff has transactions and cannot be deleted"><i class="fas fa-trash"></i></button><?php } ?><?php } ?></td></tr><?php } ?></tbody></table></div></div>
<div class="modal fade" id="staff-photo-preview-modal" tabindex="-1" role="dialog" aria-labelledby="staff-photo-preview-title" aria-hidden="true"><div class="modal-dialog modal-dialog-centered modal-lg" role="document"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staff-photo-preview-title">Staff Photo</h5><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body text-center p-3"><img id="staff-photo-preview-image" src="" alt="" style="max-width:100%;max-height:70vh;object-fit:contain"></div></div></div></div>
<script>document.addEventListener('click',async function(event){const button=event.target.closest('.staff-ajax-action');if(!button||button.disabled)return;const action=button.dataset.staffAction;if(action==='delete'&&!confirm('Delete this staff?'))return;button.disabled=true;try{const response=await fetch('index.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:new URLSearchParams({action:'ajax_staff_action',staff_id:button.dataset.staffId,staff_action:action})});const data=await response.json();if(!response.ok||!data.success)throw new Error(data.message||'Action could not be completed.');const row=button.closest('tr');if(action==='delete'){if(window.jQuery&&jQuery.fn.DataTable&&jQuery.fn.DataTable.isDataTable('#example1'))jQuery('#example1').DataTable().row(row).remove().draw(false);else row.remove();return;}const active=data.status==='active';const badge=row.querySelector('.staff-status-badge');badge.textContent=data.status;badge.className='badge staff-status-badge '+(active?'badge-success':'badge-secondary');button.className='btn btn-sm staff-ajax-action staff-toggle-action '+(active?'btn-secondary':'btn-success');button.title=active?'Make Inactive':'Make Active';button.innerHTML=active?'<i class="fas fa-toggle-off"></i>':'<i class="fas fa-toggle-on"></i>';}catch(error){alert(error.message||'Action could not be completed.');}finally{button.disabled=false;}});</script>
<?php $page_script = <<<'SCRIPT'
<script>
$(function () {
    const staffTable = $('#example1').DataTable();
    staffTable.on('draw.dt', function () {
        const pageStart = staffTable.page.info().start;
        staffTable.column(0, { page: 'current' }).nodes().each(function (cell, index) {
            cell.textContent = pageStart + index + 1;
        });
    }).draw(false);

    $(document).on('click', '.staff-photo-preview', function () {
        $('#staff-photo-preview-image').attr({src: this.dataset.photoSrc, alt: this.dataset.photoAlt || 'Staff photo'});
        $('#staff-photo-preview-title').text(this.dataset.photoAlt || 'Staff Photo');
        $('#staff-photo-preview-modal').modal('show');
    });
});
</script>
SCRIPT;
require_once '../includes/footer.php'; ?>
