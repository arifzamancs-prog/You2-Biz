<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/staff_attendance_helper.php';

require_staff_manage_access();
$user_id = (int)$_SESSION['user_id'];
ensure_staff_attendance_tables($conn);
ensure_head_office_branch($conn, $user_id);
$message = '';
$message_type = 'success';
$is_ajax = $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === '1';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $action = $_POST['action'] ?? '';

    if($action === 'review_leave_application'){
        $application_id = (int)($_POST['application_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        if(!manager_can_modify() || !in_array($decision, ['approved', 'rejected'], true) || $application_id <= 0){
            $message = 'Leave application request is invalid.';
            $message_type = 'danger';
        }else{
            $application_stmt = mysqli_prepare($conn, 'SELECT * FROM staff_leave_applications WHERE id=? AND user_id=? AND status=\'pending\' LIMIT 1');
            mysqli_stmt_bind_param($application_stmt, 'ii', $application_id, $user_id);
            mysqli_stmt_execute($application_stmt);
            $application = mysqli_fetch_assoc(mysqli_stmt_get_result($application_stmt));
            if(!$application){
                $message = 'Leave application was not found or has already been reviewed.';
                $message_type = 'danger';
            }else{
                if($decision === 'approved'){
                    $attendance_status = $application['leave_type'];
                    $application_staff_id = (int)$application['staff_id'];
                    $application_login_user_id = (int)$application['login_user_id'];
                    $application_date = $application['application_date'];
                    $attendance_stmt = mysqli_prepare($conn, "INSERT INTO staff_attendance_logs (user_id, staff_id, login_user_id, attendance_date, login_at, login_ip, login_device, attendance_status, is_auto_absent) VALUES (?, ?, ?, ?, NOW(), '', 'leave_application', ?, 0) ON DUPLICATE KEY UPDATE login_user_id=VALUES(login_user_id), login_ip='', login_device='leave_application', attendance_status=VALUES(attendance_status), is_auto_absent=0");
                    mysqli_stmt_bind_param($attendance_stmt, 'iiiss', $user_id, $application_staff_id, $application_login_user_id, $application_date, $attendance_status);
                    mysqli_stmt_execute($attendance_stmt);
                    staff_attendance_reconcile_monthly_salary($conn,$user_id,$application_staff_id,$application_date);
                }
                $reviewed_by = (int)($_SESSION['login_user_id'] ?? $user_id);
                $review_stmt = mysqli_prepare($conn, 'UPDATE staff_leave_applications SET status=?, reviewed_by=?, reviewed_at=NOW() WHERE id=? AND user_id=?');
                mysqli_stmt_bind_param($review_stmt, 'siii', $decision, $reviewed_by, $application_id, $user_id);
                mysqli_stmt_execute($review_stmt);
                header('Location: attendance.php?leave_reviewed=1');
                exit;
            }
        }
    }

    if($action === 'save_settings'){
        $start = $_POST['office_start_time'] ?? '10:00';
        $late_after = $_POST['late_after_time'] ?? '10:15';
        $absent_after = $_POST['absent_after_time'] ?? '12:00';
        $late_days = max(1, (int)($_POST['late_days_for_salary_cut'] ?? 3));
        // One salary-cut day equals the percentage represented by one calendar day this month.
        $cut_type = 'percentage';
        $cut_value = round(100 / (int)date('t'), 2);
        $stmt = mysqli_prepare($conn, "UPDATE staff_attendance_settings SET office_start_time=?, late_after_time=?, absent_after_time=?, late_days_for_salary_cut=?, salary_cut_type=?, salary_cut_value=? WHERE user_id=?");
        mysqli_stmt_bind_param($stmt, 'sssisdi', $start, $late_after, $absent_after, $late_days, $cut_type, $cut_value, $user_id);
        mysqli_stmt_execute($stmt);
        $message = 'Attendance rules updated.';
    }

    if($action === 'add_closed_day'){
        $date = $_POST['closed_date'] ?? '';
        $title = trim($_POST['closed_title'] ?? '') ?: 'Office Closed';
        if($date !== ''){
            $stmt = mysqli_prepare($conn, 'INSERT INTO staff_office_closed_days (user_id, closed_date, title) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE title=VALUES(title)');
            mysqli_stmt_bind_param($stmt, 'iss', $user_id, $date, $title);
            mysqli_stmt_execute($stmt);
            $message = 'Office closed day saved.';

            $saved_day_stmt = mysqli_prepare($conn, 'SELECT id, closed_date, title FROM staff_office_closed_days WHERE user_id=? AND closed_date=? LIMIT 1');
            mysqli_stmt_bind_param($saved_day_stmt, 'is', $user_id, $date);
            mysqli_stmt_execute($saved_day_stmt);
            $saved_day = mysqli_fetch_assoc(mysqli_stmt_get_result($saved_day_stmt)) ?: null;
        }
    }

    if($action === 'delete_closed_day'){
        $id = (int)($_POST['closed_day_id'] ?? 0);
        $day_stmt = mysqli_prepare($conn, 'SELECT closed_date FROM staff_office_closed_days WHERE id=? AND user_id=? LIMIT 1');
        mysqli_stmt_bind_param($day_stmt, 'ii', $id, $user_id);
        mysqli_stmt_execute($day_stmt);
        $day_record = mysqli_fetch_assoc(mysqli_stmt_get_result($day_stmt));
        if(!$day_record || $day_record['closed_date'] < date('Y-m-d')){
            $message = 'Past office closed days cannot be removed.';
            $message_type = 'danger';
        }else{
            $stmt = mysqli_prepare($conn, 'DELETE FROM staff_office_closed_days WHERE id=? AND user_id=?');
            mysqli_stmt_bind_param($stmt, 'ii', $id, $user_id);
            mysqli_stmt_execute($stmt);
            $message = 'Closed day removed.';
        }
    }

    if($action === 'update_attendance_status'){
        $attendance_id = (int)($_POST['attendance_id'] ?? 0);
        $status = $_POST['attendance_status'] ?? '';
        $allowed_statuses = ['present', 'late', 'absent', 'closed_day', 'casual_leave', 'medical_leave'];
        if(!manager_can_modify()){
            $message = 'You do not have permission to update attendance status.';
            $message_type = 'danger';
        }else{
            if($attendance_id <= 0 || !in_array($status, $allowed_statuses, true)){
                $message = 'Attendance status is invalid.';
                $message_type = 'danger';
            }else{
                // A manual correction must no longer be treated as an automatic absence.
                $stmt = mysqli_prepare($conn, 'UPDATE staff_attendance_logs SET attendance_status=?, is_auto_absent=0 WHERE id=? AND user_id=?');
                if(!$stmt){
                    $message = 'Attendance record could not be updated.';
                    $message_type = 'danger';
                }else{
                    mysqli_stmt_bind_param($stmt, 'sii', $status, $attendance_id, $user_id);
                    if(!mysqli_stmt_execute($stmt)){
                        $message = 'Attendance record could not be updated.';
                        $message_type = 'danger';
                }else{
                    $record_stmt=mysqli_prepare($conn,'SELECT staff_id,attendance_date FROM staff_attendance_logs WHERE id=? AND user_id=? LIMIT 1'); mysqli_stmt_bind_param($record_stmt,'ii',$attendance_id,$user_id); mysqli_stmt_execute($record_stmt); $record=mysqli_fetch_assoc(mysqli_stmt_get_result($record_stmt));
                    $salary_sync=$record?staff_attendance_reconcile_monthly_salary($conn,$user_id,(int)$record['staff_id'],$record['attendance_date']):['updated'=>false,'paid'=>false];
                    $message = $salary_sync['updated'] ? 'Attendance status updated and pending salary recalculated.' : ($salary_sync['paid'] ? 'Attendance status updated. The related salary is already paid, so its posted payment was not changed.' : 'Attendance status updated.');
                    if(!$is_ajax){
                        header('Location: attendance.php?status_updated=1&salary_recalculated='.($salary_sync['updated']?'1':($salary_sync['paid']?'paid':'0')));
                        exit;
                    }
                }
                }
            }
        }
    }

    if($is_ajax){
        header('Content-Type: application/json; charset=utf-8');
        if(($action === 'add_closed_day' && empty($saved_day)) || $message_type === 'danger'){
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => $message ?: 'Request could not be completed.']);
        }else{
            echo json_encode([
                'success' => true,
                'message' => $message,
                'action' => $action,
                'closed_day' => $saved_day ?? null,
                'closed_day_id' => $id ?? null
            ]);
        }
        exit;
    }
}

$settings = staff_attendance_settings($conn, $user_id);
staff_attendance_auto_mark_absent($conn, $user_id);
$edit_attendance = null;
$edit_attendance_id = (int)($_GET['edit_attendance'] ?? 0);
if(manager_can_modify() && $edit_attendance_id > 0){
    $edit_stmt = mysqli_prepare($conn, "SELECT a.id, a.attendance_status, a.attendance_date, s.name, s.staff_code FROM staff_attendance_logs a INNER JOIN staff s ON s.id=a.staff_id AND s.user_id=a.user_id WHERE a.id=? AND a.user_id=? LIMIT 1");
    mysqli_stmt_bind_param($edit_stmt, 'ii', $edit_attendance_id, $user_id);
    mysqli_stmt_execute($edit_stmt);
    $edit_attendance = mysqli_fetch_assoc(mysqli_stmt_get_result($edit_stmt)) ?: null;
}
$salary_cut_display_value = round(100 / (int)date('t'), 2);
$month = max(1, min(12, (int)($_GET['month'] ?? date('n'))));
$year = max(2020, min(2100, (int)($_GET['year'] ?? date('Y'))));
$month_start = sprintf('%04d-%02d-01', $year, $month);
$month_end = date('Y-m-t', strtotime($month_start));
$today = date('Y-m-d');
$log_staff_id = max(0, (int)($_GET['log_staff_id'] ?? 0));
$log_staff_filter = $log_staff_id > 0 ? ' AND a.staff_id=' . $log_staff_id : '';
$log_staffs = mysqli_query($conn, "SELECT id, staff_code, name FROM staff WHERE user_id={$user_id} AND status='active' ORDER BY name ASC");

$summary_stmt = mysqli_prepare($conn, "SELECT
    COUNT(*) AS total_logins,
    SUM(attendance_status='present') AS present_count,
    SUM(attendance_status='late') AS late_count,
    SUM(attendance_status='closed_day') AS closed_day_count
    FROM staff_attendance_logs WHERE user_id=? AND attendance_date BETWEEN ? AND ?");
mysqli_stmt_bind_param($summary_stmt, 'iss', $user_id, $month_start, $month_end);
mysqli_stmt_execute($summary_stmt);
$summary = mysqli_fetch_assoc(mysqli_stmt_get_result($summary_stmt)) ?: [];

$attendance_stmt = mysqli_prepare($conn, "SELECT a.*, s.name AS staff_name, s.staff_code, s.designation, COALESCE(NULLIF(b.branch_name,''), 'Head Office') AS branch_name
    FROM staff_attendance_logs a INNER JOIN staff s ON s.id=a.staff_id AND s.user_id=a.user_id
    LEFT JOIN branches b ON b.id=s.branch_id AND b.user_id=s.user_id
    WHERE a.user_id=? AND a.attendance_date BETWEEN ? AND ?{$log_staff_filter}
    ORDER BY a.attendance_date DESC, a.login_at DESC");
mysqli_stmt_bind_param($attendance_stmt, 'iss', $user_id, $month_start, $month_end);
mysqli_stmt_execute($attendance_stmt);
$attendance = mysqli_stmt_get_result($attendance_stmt);
$log_years = mysqli_query($conn, "SELECT DISTINCT YEAR(attendance_date) AS attendance_year FROM staff_attendance_logs WHERE user_id={$user_id} UNION SELECT " . (int)date('Y') . " ORDER BY attendance_year DESC");

$closed_stmt = mysqli_prepare($conn, 'SELECT * FROM staff_office_closed_days WHERE user_id=? ORDER BY closed_date DESC LIMIT 30');
mysqli_stmt_bind_param($closed_stmt, 'i', $user_id);
mysqli_stmt_execute($closed_stmt);
$closed_days = mysqli_stmt_get_result($closed_stmt);

$today_roster_stmt = mysqli_prepare($conn, "SELECT s.id, s.name, s.staff_code, s.designation, COALESCE(NULLIF(b.branch_name,''), 'Head Office') AS branch_name, a.id AS attendance_id, a.login_at, a.login_ip, a.attendance_status, a.is_auto_absent
    FROM staff s
    LEFT JOIN branches b ON b.id=s.branch_id AND b.user_id=s.user_id
    LEFT JOIN staff_attendance_logs a ON a.staff_id=s.id AND a.user_id=s.user_id AND a.attendance_date=?
    WHERE s.user_id=? AND s.status='active'
    ORDER BY s.name ASC");
mysqli_stmt_bind_param($today_roster_stmt, 'si', $today, $user_id);
mysqli_stmt_execute($today_roster_stmt);
$today_roster = mysqli_stmt_get_result($today_roster_stmt);
$today_is_closed_stmt = mysqli_prepare($conn, 'SELECT id FROM staff_office_closed_days WHERE user_id=? AND closed_date=? LIMIT 1');
mysqli_stmt_bind_param($today_is_closed_stmt, 'is', $user_id, $today);
mysqli_stmt_execute($today_is_closed_stmt);
$today_is_closed = mysqli_num_rows(mysqli_stmt_get_result($today_is_closed_stmt)) > 0;

$attendance_staff_id = (int)($_GET['attendance_staff_id'] ?? 0);
$attendance_summary_month = max(0, min(12, (int)($_GET['attendance_summary_month'] ?? 0)));
$attendance_year = (int)($_GET['attendance_year'] ?? date('Y'));
if ($attendance_year < 2000 || $attendance_year > ((int)date('Y') + 1)) { $attendance_year = (int)date('Y'); }
$attendance_year_start = $attendance_year . '-01-01';
$attendance_year_end = $attendance_year . '-12-31';
$attendance_filter_start = $attendance_summary_month ? sprintf('%04d-%02d-01', $attendance_year, $attendance_summary_month) : $attendance_year_start;
$attendance_filter_end = $attendance_summary_month ? date('Y-m-t', strtotime($attendance_filter_start)) : $attendance_year_end;
$attendance_staffs = mysqli_query($conn, "SELECT id, staff_code, name FROM staff WHERE user_id={$user_id} ORDER BY name ASC");
$attendance_years = mysqli_query($conn, "SELECT DISTINCT YEAR(attendance_date) AS attendance_year FROM staff_attendance_logs WHERE user_id={$user_id} UNION SELECT " . (int)date('Y') . " ORDER BY attendance_year DESC");
$attendance_staff_filter = $attendance_staff_id > 0 ? ' AND s.id=' . $attendance_staff_id : '';
$yearly_attendance_summary = mysqli_query($conn, "SELECT s.id, s.name, s.staff_code, s.designation, COALESCE(NULLIF(b.branch_name,''), 'Head Office') AS branch_name,
    COALESCE(SUM(a.attendance_status='present'),0) AS present_count,
    COALESCE(SUM(a.attendance_status='late'),0) AS late_count,
    COALESCE(SUM(a.attendance_status='absent'),0) AS absent_count,
    COALESCE(SUM(a.attendance_status='casual_leave'),0) AS casual_leave_count,
    COALESCE(SUM(a.attendance_status='medical_leave'),0) AS medical_leave_count,
    COALESCE(SUM(a.attendance_status='closed_day'),0) AS closed_day_count
    FROM staff s LEFT JOIN branches b ON b.id=s.branch_id AND b.user_id=s.user_id LEFT JOIN staff_attendance_logs a ON a.staff_id=s.id AND a.user_id=s.user_id AND a.attendance_date BETWEEN '" . mysqli_real_escape_string($conn, $attendance_filter_start) . "' AND '" . mysqli_real_escape_string($conn, $attendance_filter_end) . "'
    WHERE s.user_id={$user_id}{$attendance_staff_filter} GROUP BY s.id, s.name, s.staff_code, s.designation, b.branch_name ORDER BY s.name ASC");

$pending_leave_stmt = mysqli_prepare($conn, "SELECT la.*, s.name AS staff_name, s.staff_code, s.designation FROM staff_leave_applications la INNER JOIN staff s ON s.id=la.staff_id AND s.user_id=la.user_id WHERE la.user_id=? AND la.status='pending' ORDER BY la.application_date ASC, la.created_at ASC");
mysqli_stmt_bind_param($pending_leave_stmt, 'i', $user_id);
mysqli_stmt_execute($pending_leave_stmt);
$pending_leave_applications = mysqli_stmt_get_result($pending_leave_stmt);

$approved_leave_stmt = mysqli_prepare($conn, "SELECT la.*, s.name AS staff_name, s.staff_code, s.designation FROM staff_leave_applications la INNER JOIN staff s ON s.id=la.staff_id AND s.user_id=la.user_id WHERE la.user_id=? AND la.status='approved' ORDER BY la.reviewed_at DESC, la.id DESC");
mysqli_stmt_bind_param($approved_leave_stmt, 'i', $user_id);
mysqli_stmt_execute($approved_leave_stmt);
$approved_leave_applications = mysqli_stmt_get_result($approved_leave_stmt);

require_once '../includes/header.php'; require_once '../includes/navbar.php'; require_once '../includes/sidebar.php';
?>
<?php if(isset($_GET['status_updated'])): ?><div class="alert alert-<?= ($_GET['salary_recalculated']??'')==='paid'?'warning':'success' ?>"><?php if(($_GET['salary_recalculated']??'')==='1'): ?>Attendance status updated and pending salary recalculated.<?php elseif(($_GET['salary_recalculated']??'')==='paid'): ?>Attendance status updated. The related salary was already paid, so its posted payment was not changed.<?php else: ?>Attendance status updated.<?php endif; ?></div><script>window.history.replaceState({}, document.title, window.location.pathname + window.location.hash);</script><?php endif; ?>
<?php if(isset($_GET['leave_reviewed'])): ?><div class="alert alert-success">Leave application reviewed and attendance status updated.</div><script>window.history.replaceState({}, document.title, window.location.pathname + window.location.hash);</script><?php endif; ?>
<?php if(!manager_can_modify()): ?><style>.status-edit{display:none!important}</style><?php endif; ?>
<?php if($edit_attendance): ?><div id="attendance-status-editor" class="card"><div class="card-header"><h3 class="card-title">Update Attendance Status — <?=htmlspecialchars($edit_attendance['name'])?> <small class="text-muted">(<?=htmlspecialchars($edit_attendance['staff_code'])?>, <?=date('d-m-Y', strtotime($edit_attendance['attendance_date']))?>)</small></h3></div><form method="post"><div class="card-body row"><input type="hidden" name="action" value="update_attendance_status"><input type="hidden" name="attendance_id" value="<?= (int)$edit_attendance['id'] ?>"><div class="col-md-6 form-group"><label>Status</label><select name="attendance_status" class="form-control"><option value="present" <?=$edit_attendance['attendance_status']==='present'?'selected':''?>>Present</option><option value="late" <?=$edit_attendance['attendance_status']==='late'?'selected':''?>>Late</option><option value="absent" <?=$edit_attendance['attendance_status']==='absent'?'selected':''?>>Absent</option><option value="closed_day" <?=$edit_attendance['attendance_status']==='closed_day'?'selected':''?>>Office Closed Day</option><option value="casual_leave" <?=$edit_attendance['attendance_status']==='casual_leave'?'selected':''?>>Casual Leave</option><option value="medical_leave" <?=$edit_attendance['attendance_status']==='medical_leave'?'selected':''?>>Medical Leave</option></select></div><div class="col-md-6 form-group d-flex align-items-end"><button class="btn btn-primary mr-2"><i class="fas fa-save"></i> Update Status</button><a href="attendance.php" class="btn btn-secondary">Cancel</a></div></div></form></div><?php endif; ?>
<?php if(mysqli_num_rows($pending_leave_applications) > 0){ ?><div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-hourglass-half mr-2"></i>Waiting for Approval</h3></div><div class="card-body table-responsive"><table class="attendance-table table table-bordered table-striped mb-0"><thead><tr><th class="attendance-sl">SL</th><th>Date</th><th>Staff</th><th>Designation</th><th>Application Type</th><th>Application Photo</th><th>Submitted</th><th>Action</th></tr></thead><tbody><?php $attendance_sl = 0; while($leave_application=mysqli_fetch_assoc($pending_leave_applications)){ ?><tr><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?=date('d-m-Y',strtotime($leave_application['application_date']))?></td><td><?=htmlspecialchars($leave_application['staff_name'])?> <small class="text-muted">(<?=htmlspecialchars($leave_application['staff_code'])?>)</small></td><td><?=htmlspecialchars($leave_application['designation'])?></td><td><span class="badge badge-info"><?=htmlspecialchars(ucwords(str_replace('_',' ',$leave_application['leave_type'])) )?></span></td><td><?php if(!empty($leave_application['photo_path'])){ ?><a class="btn btn-outline-primary btn-sm" href="../<?=htmlspecialchars($leave_application['photo_path'])?>" target="_blank"><i class="fas fa-image"></i> View</a><?php } ?></td><td><?=date('d-m-Y',strtotime($leave_application['created_at']))?></td><td><?php if(manager_can_modify()){ ?><form method="post" class="d-inline"><input type="hidden" name="action" value="review_leave_application"><input type="hidden" name="application_id" value="<?= (int)$leave_application['id'] ?>"><button name="decision" value="approved" class="btn btn-success btn-sm" onclick="return confirm('Accept this application and update attendance?');"><i class="fas fa-check"></i> Accept</button><button name="decision" value="rejected" class="btn btn-danger btn-sm" onclick="return confirm('Reject this application?');"><i class="fas fa-times"></i> Reject</button></form><?php } else { ?><span class="text-muted">Approval permission required</span><?php } ?></td></tr><?php } ?></tbody></table></div></div><?php } ?>
<div class="row d-none">
 <div class="col-lg-7"><div class="card"><div class="card-header"><h3 class="card-title">Attendance Rules</h3></div><form id="attendance-rules-form" method="post"><div class="card-body row">
  <input type="hidden" name="action" value="save_settings"><input type="hidden" name="ajax" value="1">
  <div class="col-md-6 form-group"><label>Office Starts</label><input type="time" class="form-control" name="office_start_time" value="<?= htmlspecialchars(substr($settings['office_start_time'],0,5)) ?>"></div>
  <div class="col-md-6 form-group"><label>Late After</label><input type="time" class="form-control" name="late_after_time" value="<?= htmlspecialchars(substr($settings['late_after_time'],0,5)) ?>"></div>
  <div class="col-md-6 form-group"><label>Absent After</label><input type="time" class="form-control" name="absent_after_time" value="<?= htmlspecialchars(substr($settings['absent_after_time'] ?? '12:00:00',0,5)) ?>"><small class="text-muted">Desktop login after this time will be marked Absent.</small></div>
  <div class="col-md-6 form-group"><label>Salary Cut for</label><div class="input-group"><input type="number" min="1" class="form-control" name="late_days_for_salary_cut" value="<?= (int)$settings['late_days_for_salary_cut'] ?>" aria-label="Late days before salary cut"><div class="input-group-append"><span class="input-group-text">Days late</span></div></div><small class="text-muted">Example: 3 means every 3 late days will count as 1 salary-cut day.</small></div>
  <div class="col-md-6 form-group"><label>Salary Cut Type</label><input type="text" class="form-control" value="Percentage of Salary" readonly><small class="text-muted">Salary cut is always calculated from the staff member's assigned salary.</small></div>
  <div class="col-md-6 form-group"><label>Cut for per Day Absent</label><input type="text" class="form-control" value="<?= number_format($salary_cut_display_value, 2, '.', '') ?>%" readonly><small class="text-muted">This percentage is calculated automatically from the <?= (int)date('t') ?> days in the current month.</small></div>
  <div class="col-12"><div class="alert alert-light border mb-0"><i class="fas fa-info-circle text-primary mr-1"></i> Only an attendance record marked <strong>Absent</strong> counts as <strong>1 salary-cut day</strong>. No-login days remain pending until an admin updates their attendance status; office closed days are excluded. Updating attendance automatically recalculates the related <strong>pending</strong> salary.</div></div>
 </div><div class="card-footer"><span id="rules-feedback" class="text-success mr-3"></span><button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Rules</button></div></form></div></div>
 <div class="col-lg-5"><div class="card"><div class="card-header"><h3 class="card-title">Office Closed Days</h3></div><div class="card-body"><form id="closed-day-form" method="post" class="row"><input type="hidden" name="action" value="add_closed_day"><input type="hidden" name="ajax" value="1"><div class="col-5 form-group"><input type="date" required name="closed_date" class="form-control"></div><div class="col-5 form-group"><input type="text" name="closed_title" class="form-control" placeholder="Holiday name"></div><div class="col-2"><button type="submit" class="btn btn-success" title="Save closed day"><i class="fas fa-plus"></i></button></div></form><table class="attendance-table table table-sm table-bordered"><thead><tr><th class="attendance-sl">SL</th><th>Date</th><th>Reason</th><th></th></tr></thead><tbody id="closed-days-list"><?php $attendance_sl = 0; while($day=mysqli_fetch_assoc($closed_days)): $past_closed_day=$day['closed_date'] < $today; ?><tr data-closed-day-id="<?= (int)$day['id'] ?>"><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?= date('d-m-Y', strtotime($day['closed_date'])) ?></td><td><?= htmlspecialchars($day['title']) ?></td><td><button type="button" class="btn btn-danger btn-xs closed-day-delete" data-closed-day-id="<?= (int)$day['id'] ?>" title="<?= $past_closed_day ? 'Past closed days cannot be removed' : 'Remove' ?>" <?= $past_closed_day ? 'disabled' : '' ?>><i class="fas fa-trash"></i></button></td></tr><?php endwhile; ?></tbody></table></div></div></div>
</div>
<div class="card"><div class="card-header"><h3 class="card-title">Today's Attendance Roster</h3><div class="card-tools"><span class="text-muted"><?= date('d-m-Y') ?></span></div></div><div class="card-body table-responsive"><table id="attendance-roster" class="attendance-table table table-bordered table-sm mb-0"><thead><tr><th class="attendance-sl">SL</th><th>Staff</th><th>Designation</th><th>Branch</th><th>Login Time</th><th>IP Address</th><th>Status</th></tr></thead><tbody><?php $attendance_sl = 0; while($member=mysqli_fetch_assoc($today_roster)): $status=$member['attendance_status'] ?: ($today_is_closed ? 'closed_day' : (date('H:i:s') > ($settings['absent_after_time'] ?? '12:00:00') ? 'absent' : 'pending')); $auto_absent=!empty($member['is_auto_absent']) && $status==='absent'; $leave_application_record=($member['login_device'] ?? '')==='leave_application'; $badge=$status==='present'?'success':($status==='late'?'warning':($status==='absent'?'danger':'secondary')); ?><tr><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?= htmlspecialchars($member['name']) ?> <small class="text-muted">(<?= htmlspecialchars($member['staff_code']) ?>)</small></td><td><?= htmlspecialchars($member['designation']) ?></td><td><?= htmlspecialchars($member['branch_name']) ?></td><td><?= $leave_application_record ? '—' : ($auto_absent ? '—' : ($member['login_at'] ? date('h:i A', strtotime($member['login_at'])) : '—')) ?></td><td><?= $leave_application_record || $auto_absent ? '—' : htmlspecialchars($member['login_ip'] ?: '—') ?></td><td><span class="badge badge-<?= $badge ?>"><?= htmlspecialchars(ucwords(str_replace('_',' ',$status))) ?></span></td></tr><?php endwhile; ?></tbody></table></div></div>
<div class="card"><div class="card-header"><h3 class="card-title">Staff Attendance Log</h3><div class="card-tools"><form method="get" class="form-inline"><input type="hidden" name="attendance_staff_id" value="<?= $attendance_staff_id ?>"><input type="hidden" name="attendance_summary_month" value="<?= $attendance_summary_month ?>"><input type="hidden" name="attendance_year" value="<?= $attendance_year ?>"><select name="log_staff_id" class="form-control form-control-sm mr-2" aria-label="Select staff for attendance log"><option value="0">All Staff</option><?php while($log_staff=mysqli_fetch_assoc($log_staffs)): ?><option value="<?= (int)$log_staff['id'] ?>" <?= $log_staff_id===(int)$log_staff['id']?'selected':'' ?>><?= htmlspecialchars($log_staff['name']) ?> (<?= htmlspecialchars($log_staff['staff_code']) ?>)</option><?php endwhile; ?></select><select name="month" class="form-control form-control-sm mr-2" aria-label="Log month"><?php for($log_month=1;$log_month<=12;$log_month++): ?><option value="<?= $log_month ?>" <?= $month===$log_month?'selected':'' ?>><?= date('F', mktime(0,0,0,$log_month,1)) ?></option><?php endfor; ?></select><select name="year" class="form-control form-control-sm mr-2" aria-label="Log year"><?php while($log_year_row=mysqli_fetch_assoc($log_years)): $log_year=(int)$log_year_row['attendance_year']; ?><option value="<?= $log_year ?>" <?= $year===$log_year?'selected':'' ?>><?= $log_year ?></option><?php endwhile; ?></select><button class="btn btn-outline-primary btn-sm mr-2" title="View selected staff and month"><i class="fas fa-filter"></i> View</button><button type="submit" formaction="attendance_print.php" formtarget="_blank" class="btn btn-primary btn-sm"><i class="fas fa-print"></i> Print</button></form></div></div><div class="card-body table-responsive"><table id="attendance-log" class="attendance-table table table-bordered table-striped"><thead><tr><th class="attendance-sl">SL</th><th>Date</th><th>Staff</th><th>Designation</th><th>Branch</th><th>Login Time</th><th>Device</th><th>Status</th></tr></thead><tbody><?php $attendance_sl = 0; while($row=mysqli_fetch_assoc($attendance)): $class=$row['attendance_status']==='present'?'success':($row['attendance_status']==='late'?'warning':($row['attendance_status']==='absent'?'danger':'secondary')); $auto_absent=!empty($row['is_auto_absent']) && $row['attendance_status']==='absent'; $leave_application_record=($row['login_device'] ?? '')==='leave_application'; ?><tr><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?= date('d-m-Y', strtotime($row['attendance_date'])) ?></td><td><?= htmlspecialchars($row['staff_name']) ?> <small class="text-muted">(<?= htmlspecialchars($row['staff_code']) ?>)</small></td><td><?= htmlspecialchars($row['designation']) ?></td><td><?= htmlspecialchars($row['branch_name']) ?></td><td><?= $leave_application_record ? '—' : ($auto_absent ? '—' : date('h:i A', strtotime($row['login_at']))) ?></td><td><?= $leave_application_record ? '—' : ($auto_absent ? 'Auto' : 'Desktop') ?></td><td><span class="badge badge-<?= $class ?> attendance-status-badge"><?= htmlspecialchars(ucwords(str_replace('_',' ',$row['attendance_status']))) ?></span><?php if(manager_can_modify()): ?> <a href="attendance.php?month=<?= $month ?>&year=<?= $year ?>&log_staff_id=<?= $log_staff_id ?>&edit_attendance=<?= (int)$row['id'] ?>#attendance-status-editor" class="btn btn-outline-secondary btn-xs" title="Edit status"><i class="fas fa-edit"></i></a><?php endif; ?></td></tr><?php endwhile; ?></tbody></table></div></div>
<?php if(mysqli_num_rows($approved_leave_applications) > 0){ ?><div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-history mr-2"></i>Approved Leave Application History</h3></div><div class="card-body table-responsive"><table class="attendance-table table table-bordered table-striped mb-0"><thead><tr><th class="attendance-sl">SL</th><th>Date</th><th>Staff</th><th>Designation</th><th>Application Type</th><th>Application Photo</th><th>Submitted</th><th>Approved</th></tr></thead><tbody><?php $attendance_sl = 0; while($leave_application=mysqli_fetch_assoc($approved_leave_applications)){ ?><tr><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?=date('d-m-Y',strtotime($leave_application['application_date']))?></td><td><?=htmlspecialchars($leave_application['staff_name'])?> <small class="text-muted">(<?=htmlspecialchars($leave_application['staff_code'])?>)</small></td><td><?=htmlspecialchars($leave_application['designation'])?></td><td><span class="badge badge-success"><?=htmlspecialchars(ucwords(str_replace('_',' ',$leave_application['leave_type'])))?></span></td><td><?php if(!empty($leave_application['photo_path'])){ ?><a class="btn btn-outline-primary btn-sm" href="../<?=htmlspecialchars($leave_application['photo_path'])?>" target="_blank"><i class="fas fa-image"></i> View</a><?php } else { ?>-<?php } ?></td><td><?=date('d-m-Y',strtotime($leave_application['created_at']))?></td><td><?=!empty($leave_application['reviewed_at']) ? date('d-m-Y',strtotime($leave_application['reviewed_at'])) : '-'?></td></tr><?php } ?></tbody></table></div></div><?php } ?>
<div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-calendar-check mr-2"></i>Yearly Attendance Summary</h3></div><div class="card-body">
<form method="get" class="row align-items-end mb-3"><input type="hidden" name="month" value="<?= $month ?>"><input type="hidden" name="year" value="<?= $year ?>"><div class="col-md-4 form-group mb-md-0"><label>Staff</label><select name="attendance_staff_id" class="form-control"><option value="0">All Staff</option><?php while($attendance_staff=mysqli_fetch_assoc($attendance_staffs)){ ?><option value="<?=$attendance_staff['id']?>" <?=$attendance_staff_id===(int)$attendance_staff['id']?'selected':''?>><?=htmlspecialchars($attendance_staff['name'])?> (<?=htmlspecialchars($attendance_staff['staff_code'])?>)</option><?php } ?></select></div><div class="col-md-3 form-group mb-md-0"><label>Month</label><select name="attendance_summary_month" class="form-control"><option value="0" <?=$attendance_summary_month===0?'selected':''?>>All Months</option><?php for($summary_month=1;$summary_month<=12;$summary_month++): ?><option value="<?=$summary_month?>" <?=$attendance_summary_month===$summary_month?'selected':''?>><?=date('F', mktime(0,0,0,$summary_month,1))?></option><?php endfor; ?></select></div><div class="col-md-2 form-group mb-md-0"><label>Year</label><select name="attendance_year" class="form-control"><?php while($year_row=mysqli_fetch_assoc($attendance_years)){ $year_value=(int)$year_row['attendance_year']; ?><option value="<?=$year_value?>" <?=$attendance_year===$year_value?'selected':''?>><?=$year_value?></option><?php } ?></select></div><div class="col-md-3 mt-3 mt-md-0"><button class="btn btn-primary mr-1"><i class="fas fa-filter"></i> View Attendance</button><button type="submit" formaction="attendance_summary_print.php" formtarget="_blank" class="btn btn-outline-primary"><i class="fas fa-print"></i> Print</button></div></form>
<div class="table-responsive"><table id="attendance-yearly" class="attendance-table table table-bordered table-striped"><thead><tr><th class="attendance-sl">SL</th><th>Staff</th><th>Designation</th><th>Branch</th><th class="text-center">Present</th><th class="text-center">Late</th><th class="text-center">Absent</th><th class="text-center">Casual Leave</th><th class="text-center">Medical Leave</th></tr></thead><tbody><?php $attendance_sl = 0; while($yearly_summary=mysqli_fetch_assoc($yearly_attendance_summary)){ ?><tr><td class="attendance-sl"><?= ++$attendance_sl ?></td><td><?=htmlspecialchars($yearly_summary['name'])?> <small class="text-muted">(<?=htmlspecialchars($yearly_summary['staff_code'])?>)</small></td><td><?=htmlspecialchars($yearly_summary['designation'] ?: '-')?></td><td><?= htmlspecialchars($yearly_summary['branch_name']) ?></td><td class="text-center"><span class="badge badge-success"><?=(int)$yearly_summary['present_count']?></span></td><td class="text-center"><span class="badge badge-warning"><?=(int)$yearly_summary['late_count']?></span></td><td class="text-center"><span class="badge badge-danger"><?=(int)$yearly_summary['absent_count']?></span></td><td class="text-center"><span class="badge badge-info"><?=(int)$yearly_summary['casual_leave_count']?></span></td><td class="text-center"><span class="badge badge-primary"><?=(int)$yearly_summary['medical_leave_count']?></span></td></tr><?php } ?></tbody></table></div>
</div></div>
<div class="modal fade" id="attendanceStatusModal" tabindex="-1"><div class="modal-dialog"><form id="attendance-status-form" class="modal-content"><div class="modal-header"><h5 class="modal-title">Update Attendance Status</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div><div class="modal-body"><input type="hidden" name="action" value="update_attendance_status"><input type="hidden" name="ajax" value="1"><input type="hidden" name="attendance_id" id="attendance-status-id"><div class="form-group mb-0"><label>Status</label><select name="attendance_status" id="attendance-status-value" class="form-control"><option value="present">Present</option><option value="late">Late</option><option value="absent">Absent</option><option value="closed_day">Office Closed Day</option><option value="casual_leave">Casual Leave</option><option value="medical_leave">Medical Leave</option></select><small class="text-muted">Casual Leave and Medical Leave do not create a salary cut.</small></div></div><div class="modal-footer"><span id="status-feedback" class="text-danger mr-auto"></span><button type="submit" class="btn btn-primary">Update Status</button></div></form></div></div>
<script>
const renumberClosedDays = () => {
 document.querySelectorAll('#closed-days-list tr').forEach((row, index) => {
  row.children[0].textContent = index + 1;
 });
};
const attendancePost = async (formData) => {
 const response = await fetch('attendance.php', {method: 'POST', body: formData});
 const data = await response.json();
 if (!response.ok || !data.success) throw new Error(data.message || 'Request could not be completed.');
 return data;
};
const setRulesFeedback = (message, isError = false) => {
 const box = document.getElementById('rules-feedback');
 box.className = isError ? 'text-danger mr-3' : 'text-success mr-3';
 box.textContent = message;
};
document.getElementById('attendance-rules-form').addEventListener('submit', async function(event) {
 event.preventDefault();
 const button = this.querySelector('button[type="submit"]'); button.disabled = true;
 try { const data = await attendancePost(new FormData(this)); setRulesFeedback(data.message); }
 catch (error) { setRulesFeedback(error.message, true); }
 finally { button.disabled = false; }
});
document.getElementById('closed-day-form').addEventListener('submit', async function(event) {
 event.preventDefault();
 const form = this, button = form.querySelector('button[type="submit"]'); button.disabled = true;
 try {
  const data = await attendancePost(new FormData(form));
  const day = data.closed_day;
  const row = document.querySelector('[data-closed-day-id="' + day.id + '"]');
  const parts = day.closed_date.split('-'); const dateText = parts[2] + '-' + parts[1] + '-' + parts[0];
  const html = '<tr data-closed-day-id="' + day.id + '"><td class="attendance-sl"></td><td>' + dateText + '</td><td></td><td><button type="button" class="btn btn-danger btn-xs closed-day-delete" data-closed-day-id="' + day.id + '" title="Remove"><i class="fas fa-trash"></i></button></td></tr>';
  if (row) { row.children[1].textContent = dateText; row.children[2].textContent = day.title; } else { document.getElementById('closed-days-list').insertAdjacentHTML('afterbegin', html); document.querySelector('[data-closed-day-id="' + day.id + '"] td:nth-child(3)').textContent = day.title; }
  renumberClosedDays();
  form.reset();
 } catch (error) { alert(error.message); } finally { button.disabled = false; }
});
document.getElementById('closed-days-list').addEventListener('click', async function(event) {
 const button = event.target.closest('.closed-day-delete'); if (!button || button.disabled) return;
 if (!confirm('Remove this office closed day?')) return;
 button.disabled = true;
 const formData = new FormData(); formData.append('action', 'delete_closed_day'); formData.append('ajax', '1'); formData.append('closed_day_id', button.dataset.closedDayId);
 try { await attendancePost(formData); button.closest('tr').remove(); renumberClosedDays(); }
 catch (error) { alert(error.message); button.disabled = false; }
});
document.addEventListener('click', function(event) {
 const button = event.target.closest('.status-edit'); if (!button) return;
 window.location.href = 'attendance.php?edit_attendance=' + encodeURIComponent(button.dataset.id);
});
document.getElementById('attendance-status-form').addEventListener('submit', async function(event) {
 event.preventDefault();
 const form = this, button = form.querySelector('button[type="submit"]'); button.disabled = true;
 try {
  const data = await attendancePost(new FormData(form));
  $('#attendanceStatusModal').modal('hide');
  window.location.reload();
 } catch (error) { document.getElementById('status-feedback').textContent = error.message; }
 finally { button.disabled = false; }
});
</script>
<?php
$page_script = <<<'HTML'
<style>
.attendance-table { width: 100% !important; table-layout: auto; }
.attendance-table th, .attendance-table td { vertical-align: middle; }
.attendance-table th { white-space: nowrap; }
.attendance-table .attendance-sl { width: 1%; white-space: nowrap; text-align: center; }
.attendance-table td { overflow-wrap: anywhere; }
.attendance-table td small { display: inline-block; }
.attendance-table .badge, .attendance-table .btn { white-space: nowrap; }
#attendance-roster .attendance-sl { width: 5%; }
#attendance-roster th:nth-child(3), #attendance-roster td:nth-child(3) { width: 11%; }
#attendance-roster th:nth-child(6), #attendance-roster td:nth-child(6) { width: 20%; }
#attendance-roster th:nth-child(5), #attendance-roster td:nth-child(5),
#attendance-roster th:nth-child(7), #attendance-roster td:nth-child(7) { width: 1%; white-space: nowrap; }
#attendance-log .attendance-sl { width: 5%; }
#attendance-log th:nth-child(3), #attendance-log td:nth-child(3) { width: 27%; }
#attendance-log th:nth-child(4), #attendance-log td:nth-child(4) { width: 10%; }
#attendance-log th:nth-child(n+5), #attendance-log td:nth-child(n+5) { width: 1%; white-space: nowrap; }
#attendance-yearly .attendance-sl { width: 5%; }
#attendance-yearly th:nth-child(3), #attendance-yearly td:nth-child(3) { width: 11%; }
#attendance-yearly th:nth-child(n+5), #attendance-yearly td:nth-child(n+5) { width: 1%; white-space: nowrap; }
</style>
<script>
$(function () {
 ['attendance-roster', 'attendance-log', 'attendance-yearly'].forEach(function (id) {
  $('#' + id).DataTable({
   pageLength: 10,
   lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
   searching: true,
   lengthChange: true,
   autoWidth: false,
   responsive: false,
   order: [],
   columnDefs: [{ targets: 0, orderable: false, searchable: false }],
   drawCallback: function () {
    var api = this.api();
    var start = api.page.info().start;
    api.column(0, { page: 'current' }).nodes().each(function (cell, index) {
     cell.textContent = start + index + 1;
    });
   }
  });
 });
});
</script>
HTML;
require_once '../includes/footer.php';
?>
