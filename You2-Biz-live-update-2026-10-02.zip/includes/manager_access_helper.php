<?php
require_once __DIR__ . '/supplier_label_helper.php';

function ensure_manager_access_columns($conn)
{
    static $checked = false;

    if($checked){
        return;
    }

    $checked = true;

    $columns = [
        'manager_type' => "ALTER TABLE users ADD COLUMN manager_type VARCHAR(20) NOT NULL DEFAULT 'manager'",
        'max_managers' => "ALTER TABLE users ADD COLUMN max_managers INT NOT NULL DEFAULT 2",
        'staff_id' => "ALTER TABLE users ADD COLUMN staff_id BIGINT UNSIGNED NULL",
        'access_permissions' => "ALTER TABLE users ADD COLUMN access_permissions TEXT NULL",
    ];

    foreach($columns as $column => $sql){
        $result = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE '" . mysqli_real_escape_string($conn, $column) . "'");

        if($result && mysqli_num_rows($result) === 0){
            mysqli_query($conn, $sql);
        }
    }

    $index = mysqli_query($conn, "SHOW INDEX FROM users WHERE Key_name='idx_users_staff_id'");
    if($index && mysqli_num_rows($index) === 0){
        mysqli_query($conn, "ALTER TABLE users ADD INDEX idx_users_staff_id (staff_id)");
    }
}

function available_manager_permissions($project_package_labels = null)
{
    $project_package_label = is_array($project_package_labels)
        ? ($project_package_labels['module'] ?? 'Project & Package')
        : 'Project & Package';

    return [
        'main_dashboard' => 'Main Dashboard',
        'dashboard' => 'Branch Dashboard',
        'all_branches' => 'All Branches',
        'staff' => 'Staff Manage',
        'sales' => 'Sales / Invoice',
        'stock_sales' => 'Sales',
        'products' => 'Products',
        'warehouse' => 'Main Warehouse',
        'stock_live_report' => 'Stock Live Report',
        'wallets' => 'Wallets',
        'projects' => $project_package_label,
        'land_ledger' => 'Land Ledger',
        'customers' => 'Customer Manage',
        'leads' => 'Lead Management',
        'suppliers' => supplier_display_text('Suppliers'),
        'admin' => 'Admin',
        // These are shown as Admin sub-options in Access Management, rather
        // than as regular module permissions. Tools is intentionally a regular
        // permission so it can be assigned independently of Admin access.
        'admin_access_management' => 'Access Management',
        'attendance_settings' => 'Attendance Settings',
        'wallet_approvals' => 'Wallet Approvals',
        'branch_management' => 'Branch Management',
        'invoice_charges' => 'Invoice Charges',
        'printing_option' => 'Printing Option',
        'profit_cash_out' => 'Profit Cash Out',
        'sidebar_settings' => 'Slidebar Settings',
        'admin_sidebar_configured' => 'Admin sidebar configured',
        'tools' => 'Tools',
        'notice_publish' => 'Notice Publish',
        'reports' => 'Reports',
    ];
}

function admin_sidebar_permissions()
{
    return [
        'admin_access_management' => 'Access Management',
        'attendance_settings' => 'Attendance Settings',
        'wallet_approvals' => 'Wallet Approvals',
        'branch_management' => 'Branch Management',
        'invoice_charges' => 'Invoice Charges',
        'printing_option' => 'Printing Option',
        'profit_cash_out' => 'Profit Cash Out',
        'sidebar_settings' => 'Slidebar Settings',
    ];
}

function manager_has_selected_admin_sidebar_permission($permission)
{
    if(!function_exists('is_manager_user') || !is_manager_user() || empty($_SESSION['permissions_configured'])){
        return true;
    }

    $permissions = $_SESSION['access_permissions'] ?? [];
    if(!in_array('admin', $permissions, true)){
        return false;
    }

    // Existing accounts created before granular Admin options keep their
    // former full Admin access until the access record is saved again.
    if(!in_array('admin_sidebar_configured', $permissions, true)){
        return true;
    }

    return in_array($permission, $permissions, true);
}

function normalize_manager_permissions($permissions)
{
    $permissions = is_array($permissions) ? $permissions : [];
    return array_values(array_intersect(array_keys(available_manager_permissions()), $permissions));
}

function normalize_manager_type($manager_type)
{
    return $manager_type === 'agent' ? 'agent' : 'manager';
}
